/********************************************************************************
** Form generated from reading UI file 'staticmapwidget.ui'
**
** Created by: Qt User Interface Compiler version 5.10.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_STATICMAPWIDGET_H
#define UI_STATICMAPWIDGET_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_staticMapWidget
{
public:

    void setupUi(QWidget *staticMapWidget)
    {
        if (staticMapWidget->objectName().isEmpty())
            staticMapWidget->setObjectName(QStringLiteral("staticMapWidget"));
        staticMapWidget->resize(400, 300);

        retranslateUi(staticMapWidget);

        QMetaObject::connectSlotsByName(staticMapWidget);
    } // setupUi

    void retranslateUi(QWidget *staticMapWidget)
    {
        staticMapWidget->setWindowTitle(QApplication::translate("staticMapWidget", "Form", nullptr));
    } // retranslateUi

};

namespace Ui {
    class staticMapWidget: public Ui_staticMapWidget {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_STATICMAPWIDGET_H
