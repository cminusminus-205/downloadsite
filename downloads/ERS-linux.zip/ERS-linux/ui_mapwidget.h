/********************************************************************************
** Form generated from reading UI file 'mapwidget.ui'
**
** Created by: Qt User Interface Compiler version 5.10.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAPWIDGET_H
#define UI_MAPWIDGET_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_mapWidget
{
public:

    void setupUi(QWidget *mapWidget)
    {
        if (mapWidget->objectName().isEmpty())
            mapWidget->setObjectName(QStringLiteral("mapWidget"));
        mapWidget->resize(400, 300);

        retranslateUi(mapWidget);

        QMetaObject::connectSlotsByName(mapWidget);
    } // setupUi

    void retranslateUi(QWidget *mapWidget)
    {
        mapWidget->setWindowTitle(QApplication::translate("mapWidget", "Form", nullptr));
    } // retranslateUi

};

namespace Ui {
    class mapWidget: public Ui_mapWidget {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAPWIDGET_H
