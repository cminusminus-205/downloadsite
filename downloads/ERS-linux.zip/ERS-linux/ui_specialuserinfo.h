/********************************************************************************
** Form generated from reading UI file 'specialuserinfo.ui'
**
** Created by: Qt User Interface Compiler version 5.10.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SPECIALUSERINFO_H
#define UI_SPECIALUSERINFO_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_SpecialUserInfo
{
public:
    QWidget *verticalLayoutWidget_2;
    QVBoxLayout *verticalLayout_2;
    QSpacerItem *verticalSpacer_3;
    QHBoxLayout *horizontalLayout_2;
    QSpacerItem *horizontalSpacer;
    QVBoxLayout *verticalLayout;
    QComboBox *workType;
    QLineEdit *otherType;
    QLineEdit *station;
    QLineEdit *zip;
    QHBoxLayout *horizontalLayout;
    QPushButton *Cancel;
    QSpacerItem *horizontalSpacer_3;
    QPushButton *Next;
    QSpacerItem *horizontalSpacer_2;
    QSpacerItem *verticalSpacer_2;

    void setupUi(QWidget *SpecialUserInfo)
    {
        if (SpecialUserInfo->objectName().isEmpty())
            SpecialUserInfo->setObjectName(QStringLiteral("SpecialUserInfo"));
        SpecialUserInfo->resize(900, 600);
        QPalette palette;
        QBrush brush(QColor(0, 0, 0, 255));
        brush.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::WindowText, brush);
        QBrush brush1(QColor(239, 41, 41, 255));
        brush1.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::Button, brush1);
        QBrush brush2(QColor(255, 147, 147, 255));
        brush2.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::Light, brush2);
        QBrush brush3(QColor(247, 94, 94, 255));
        brush3.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::Midlight, brush3);
        QBrush brush4(QColor(119, 20, 20, 255));
        brush4.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::Dark, brush4);
        QBrush brush5(QColor(159, 27, 27, 255));
        brush5.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::Mid, brush5);
        palette.setBrush(QPalette::Active, QPalette::Text, brush);
        QBrush brush6(QColor(255, 255, 255, 255));
        brush6.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::BrightText, brush6);
        palette.setBrush(QPalette::Active, QPalette::ButtonText, brush);
        palette.setBrush(QPalette::Active, QPalette::Base, brush6);
        QBrush brush7(QColor(238, 238, 236, 255));
        brush7.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::Window, brush7);
        palette.setBrush(QPalette::Active, QPalette::Shadow, brush);
        QBrush brush8(QColor(247, 148, 148, 255));
        brush8.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::AlternateBase, brush8);
        QBrush brush9(QColor(255, 255, 220, 255));
        brush9.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::ToolTipBase, brush9);
        palette.setBrush(QPalette::Active, QPalette::ToolTipText, brush);
        palette.setBrush(QPalette::Inactive, QPalette::WindowText, brush);
        palette.setBrush(QPalette::Inactive, QPalette::Button, brush1);
        palette.setBrush(QPalette::Inactive, QPalette::Light, brush2);
        palette.setBrush(QPalette::Inactive, QPalette::Midlight, brush3);
        palette.setBrush(QPalette::Inactive, QPalette::Dark, brush4);
        palette.setBrush(QPalette::Inactive, QPalette::Mid, brush5);
        palette.setBrush(QPalette::Inactive, QPalette::Text, brush);
        palette.setBrush(QPalette::Inactive, QPalette::BrightText, brush6);
        palette.setBrush(QPalette::Inactive, QPalette::ButtonText, brush);
        palette.setBrush(QPalette::Inactive, QPalette::Base, brush6);
        palette.setBrush(QPalette::Inactive, QPalette::Window, brush7);
        palette.setBrush(QPalette::Inactive, QPalette::Shadow, brush);
        palette.setBrush(QPalette::Inactive, QPalette::AlternateBase, brush8);
        palette.setBrush(QPalette::Inactive, QPalette::ToolTipBase, brush9);
        palette.setBrush(QPalette::Inactive, QPalette::ToolTipText, brush);
        palette.setBrush(QPalette::Disabled, QPalette::WindowText, brush4);
        palette.setBrush(QPalette::Disabled, QPalette::Button, brush1);
        palette.setBrush(QPalette::Disabled, QPalette::Light, brush2);
        palette.setBrush(QPalette::Disabled, QPalette::Midlight, brush3);
        palette.setBrush(QPalette::Disabled, QPalette::Dark, brush4);
        palette.setBrush(QPalette::Disabled, QPalette::Mid, brush5);
        palette.setBrush(QPalette::Disabled, QPalette::Text, brush4);
        palette.setBrush(QPalette::Disabled, QPalette::BrightText, brush6);
        palette.setBrush(QPalette::Disabled, QPalette::ButtonText, brush4);
        palette.setBrush(QPalette::Disabled, QPalette::Base, brush7);
        palette.setBrush(QPalette::Disabled, QPalette::Window, brush7);
        palette.setBrush(QPalette::Disabled, QPalette::Shadow, brush);
        palette.setBrush(QPalette::Disabled, QPalette::AlternateBase, brush1);
        palette.setBrush(QPalette::Disabled, QPalette::ToolTipBase, brush9);
        palette.setBrush(QPalette::Disabled, QPalette::ToolTipText, brush);
        SpecialUserInfo->setPalette(palette);
        QFont font;
        font.setFamily(QStringLiteral("DejaVu Sans"));
        font.setBold(false);
        font.setWeight(50);
        SpecialUserInfo->setFont(font);
        verticalLayoutWidget_2 = new QWidget(SpecialUserInfo);
        verticalLayoutWidget_2->setObjectName(QStringLiteral("verticalLayoutWidget_2"));
        verticalLayoutWidget_2->setGeometry(QRect(10, 10, 881, 581));
        verticalLayout_2 = new QVBoxLayout(verticalLayoutWidget_2);
        verticalLayout_2->setObjectName(QStringLiteral("verticalLayout_2"));
        verticalLayout_2->setContentsMargins(0, 0, 0, 0);
        verticalSpacer_3 = new QSpacerItem(20, 50, QSizePolicy::Minimum, QSizePolicy::Fixed);

        verticalLayout_2->addItem(verticalSpacer_3);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName(QStringLiteral("horizontalLayout_2"));
        horizontalSpacer = new QSpacerItem(100, 20, QSizePolicy::Fixed, QSizePolicy::Minimum);

        horizontalLayout_2->addItem(horizontalSpacer);

        verticalLayout = new QVBoxLayout();
        verticalLayout->setSpacing(70);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        workType = new QComboBox(verticalLayoutWidget_2);
        workType->addItem(QString());
        workType->addItem(QString());
        workType->addItem(QString());
        workType->addItem(QString());
        workType->addItem(QString());
        workType->addItem(QString());
        workType->addItem(QString());
        workType->addItem(QString());
        workType->setObjectName(QStringLiteral("workType"));
        workType->setFont(font);
        workType->setStyleSheet(QStringLiteral("background-color: rgb(114, 159, 207);"));

        verticalLayout->addWidget(workType);

        otherType = new QLineEdit(verticalLayoutWidget_2);
        otherType->setObjectName(QStringLiteral("otherType"));
        otherType->setFont(font);

        verticalLayout->addWidget(otherType);

        station = new QLineEdit(verticalLayoutWidget_2);
        station->setObjectName(QStringLiteral("station"));
        station->setFont(font);

        verticalLayout->addWidget(station);

        zip = new QLineEdit(verticalLayoutWidget_2);
        zip->setObjectName(QStringLiteral("zip"));
        zip->setFont(font);

        verticalLayout->addWidget(zip);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        Cancel = new QPushButton(verticalLayoutWidget_2);
        Cancel->setObjectName(QStringLiteral("Cancel"));
        Cancel->setFont(font);
        Cancel->setStyleSheet(QStringLiteral("background-color: rgb(114, 159, 207);"));

        horizontalLayout->addWidget(Cancel);

        horizontalSpacer_3 = new QSpacerItem(80, 20, QSizePolicy::Fixed, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer_3);

        Next = new QPushButton(verticalLayoutWidget_2);
        Next->setObjectName(QStringLiteral("Next"));
        Next->setFont(font);
        Next->setStyleSheet(QStringLiteral("background-color: rgb(114, 159, 207);"));

        horizontalLayout->addWidget(Next);


        verticalLayout->addLayout(horizontalLayout);


        horizontalLayout_2->addLayout(verticalLayout);

        horizontalSpacer_2 = new QSpacerItem(100, 20, QSizePolicy::Fixed, QSizePolicy::Minimum);

        horizontalLayout_2->addItem(horizontalSpacer_2);


        verticalLayout_2->addLayout(horizontalLayout_2);

        verticalSpacer_2 = new QSpacerItem(20, 50, QSizePolicy::Minimum, QSizePolicy::Fixed);

        verticalLayout_2->addItem(verticalSpacer_2);


        retranslateUi(SpecialUserInfo);

        QMetaObject::connectSlotsByName(SpecialUserInfo);
    } // setupUi

    void retranslateUi(QWidget *SpecialUserInfo)
    {
        SpecialUserInfo->setWindowTitle(QApplication::translate("SpecialUserInfo", "Form", nullptr));
        workType->setItemText(0, QApplication::translate("SpecialUserInfo", "Fire", nullptr));
        workType->setItemText(1, QApplication::translate("SpecialUserInfo", "Gunshot", nullptr));
        workType->setItemText(2, QApplication::translate("SpecialUserInfo", "Earthquake", nullptr));
        workType->setItemText(3, QApplication::translate("SpecialUserInfo", "Fighting", nullptr));
        workType->setItemText(4, QApplication::translate("SpecialUserInfo", "Hurricane", nullptr));
        workType->setItemText(5, QApplication::translate("SpecialUserInfo", "Flood", nullptr));
        workType->setItemText(6, QApplication::translate("SpecialUserInfo", "Zombie", nullptr));
        workType->setItemText(7, QApplication::translate("SpecialUserInfo", "Other (specify)", nullptr));

        otherType->setPlaceholderText(QApplication::translate("SpecialUserInfo", "If other worktype, specify", nullptr));
        station->setPlaceholderText(QApplication::translate("SpecialUserInfo", "Work Station", nullptr));
        zip->setPlaceholderText(QApplication::translate("SpecialUserInfo", "Work Station Zipcode", nullptr));
        Cancel->setText(QApplication::translate("SpecialUserInfo", "Cancel", nullptr));
        Next->setText(QApplication::translate("SpecialUserInfo", "Next", nullptr));
    } // retranslateUi

};

namespace Ui {
    class SpecialUserInfo: public Ui_SpecialUserInfo {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SPECIALUSERINFO_H
