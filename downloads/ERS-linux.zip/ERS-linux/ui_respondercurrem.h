/********************************************************************************
** Form generated from reading UI file 'respondercurrem.ui'
**
** Created by: Qt User Interface Compiler version 5.10.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_RESPONDERCURREM_H
#define UI_RESPONDERCURREM_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTextBrowser>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>
#include "UI/common/mapwidget.h"

QT_BEGIN_NAMESPACE

class Ui_responderCurrEm
{
public:
    QWidget *verticalLayoutWidget_2;
    QVBoxLayout *verticalLayout_2;
    QHBoxLayout *horizontalLayout_2;
    mapWidget *map;
    QVBoxLayout *verticalLayout;
    QLabel *Curr_Emergency;
    QTextBrowser *Emergency_Info;
    QHBoxLayout *horizontalLayout_3;
    QHBoxLayout *horizontalLayout;
    QHBoxLayout *horizontalLayout_4;
    QPushButton *Update_Emergency;
    QPushButton *Report_Emergency;
    QPushButton *Chat_Page;
    QPushButton *User_Center;
    QVBoxLayout *verticalLayout_3;

    void setupUi(QWidget *responderCurrEm)
    {
        if (responderCurrEm->objectName().isEmpty())
            responderCurrEm->setObjectName(QStringLiteral("responderCurrEm"));
        responderCurrEm->resize(900, 600);
        QPalette palette;
        QBrush brush(QColor(0, 0, 0, 255));
        brush.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::WindowText, brush);
        QBrush brush1(QColor(239, 41, 41, 255));
        brush1.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::Button, brush1);
        QBrush brush2(QColor(255, 147, 147, 255));
        brush2.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::Light, brush2);
        QBrush brush3(QColor(247, 94, 94, 255));
        brush3.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::Midlight, brush3);
        QBrush brush4(QColor(119, 20, 20, 255));
        brush4.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::Dark, brush4);
        QBrush brush5(QColor(159, 27, 27, 255));
        brush5.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::Mid, brush5);
        palette.setBrush(QPalette::Active, QPalette::Text, brush);
        QBrush brush6(QColor(255, 255, 255, 255));
        brush6.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::BrightText, brush6);
        palette.setBrush(QPalette::Active, QPalette::ButtonText, brush);
        palette.setBrush(QPalette::Active, QPalette::Base, brush6);
        QBrush brush7(QColor(238, 238, 236, 255));
        brush7.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::Window, brush7);
        palette.setBrush(QPalette::Active, QPalette::Shadow, brush);
        QBrush brush8(QColor(247, 148, 148, 255));
        brush8.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::AlternateBase, brush8);
        QBrush brush9(QColor(255, 255, 220, 255));
        brush9.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::ToolTipBase, brush9);
        palette.setBrush(QPalette::Active, QPalette::ToolTipText, brush);
        palette.setBrush(QPalette::Inactive, QPalette::WindowText, brush);
        palette.setBrush(QPalette::Inactive, QPalette::Button, brush1);
        palette.setBrush(QPalette::Inactive, QPalette::Light, brush2);
        palette.setBrush(QPalette::Inactive, QPalette::Midlight, brush3);
        palette.setBrush(QPalette::Inactive, QPalette::Dark, brush4);
        palette.setBrush(QPalette::Inactive, QPalette::Mid, brush5);
        palette.setBrush(QPalette::Inactive, QPalette::Text, brush);
        palette.setBrush(QPalette::Inactive, QPalette::BrightText, brush6);
        palette.setBrush(QPalette::Inactive, QPalette::ButtonText, brush);
        palette.setBrush(QPalette::Inactive, QPalette::Base, brush6);
        palette.setBrush(QPalette::Inactive, QPalette::Window, brush7);
        palette.setBrush(QPalette::Inactive, QPalette::Shadow, brush);
        palette.setBrush(QPalette::Inactive, QPalette::AlternateBase, brush8);
        palette.setBrush(QPalette::Inactive, QPalette::ToolTipBase, brush9);
        palette.setBrush(QPalette::Inactive, QPalette::ToolTipText, brush);
        palette.setBrush(QPalette::Disabled, QPalette::WindowText, brush4);
        palette.setBrush(QPalette::Disabled, QPalette::Button, brush1);
        palette.setBrush(QPalette::Disabled, QPalette::Light, brush2);
        palette.setBrush(QPalette::Disabled, QPalette::Midlight, brush3);
        palette.setBrush(QPalette::Disabled, QPalette::Dark, brush4);
        palette.setBrush(QPalette::Disabled, QPalette::Mid, brush5);
        palette.setBrush(QPalette::Disabled, QPalette::Text, brush4);
        palette.setBrush(QPalette::Disabled, QPalette::BrightText, brush6);
        palette.setBrush(QPalette::Disabled, QPalette::ButtonText, brush4);
        palette.setBrush(QPalette::Disabled, QPalette::Base, brush7);
        palette.setBrush(QPalette::Disabled, QPalette::Window, brush7);
        palette.setBrush(QPalette::Disabled, QPalette::Shadow, brush);
        palette.setBrush(QPalette::Disabled, QPalette::AlternateBase, brush1);
        palette.setBrush(QPalette::Disabled, QPalette::ToolTipBase, brush9);
        palette.setBrush(QPalette::Disabled, QPalette::ToolTipText, brush);
        responderCurrEm->setPalette(palette);
        responderCurrEm->setStyleSheet(QStringLiteral("font: \"DejaVu Sans\";"));
        verticalLayoutWidget_2 = new QWidget(responderCurrEm);
        verticalLayoutWidget_2->setObjectName(QStringLiteral("verticalLayoutWidget_2"));
        verticalLayoutWidget_2->setGeometry(QRect(10, 10, 881, 581));
        verticalLayout_2 = new QVBoxLayout(verticalLayoutWidget_2);
        verticalLayout_2->setObjectName(QStringLiteral("verticalLayout_2"));
        verticalLayout_2->setContentsMargins(0, 0, 0, 0);
        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName(QStringLiteral("horizontalLayout_2"));
        horizontalLayout_2->setSizeConstraint(QLayout::SetFixedSize);
        map = new mapWidget(verticalLayoutWidget_2);
        map->setObjectName(QStringLiteral("map"));
        QSizePolicy sizePolicy(QSizePolicy::Expanding, QSizePolicy::Preferred);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(map->sizePolicy().hasHeightForWidth());
        map->setSizePolicy(sizePolicy);

        horizontalLayout_2->addWidget(map);

        verticalLayout = new QVBoxLayout();
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        verticalLayout->setSizeConstraint(QLayout::SetFixedSize);
        verticalLayout->setContentsMargins(-1, -1, -1, 0);
        Curr_Emergency = new QLabel(verticalLayoutWidget_2);
        Curr_Emergency->setObjectName(QStringLiteral("Curr_Emergency"));
        QSizePolicy sizePolicy1(QSizePolicy::Preferred, QSizePolicy::Preferred);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(Curr_Emergency->sizePolicy().hasHeightForWidth());
        Curr_Emergency->setSizePolicy(sizePolicy1);
        QFont font;
        font.setFamily(QStringLiteral("DejaVu Sans"));
        font.setPointSize(13);
        font.setBold(false);
        font.setWeight(50);
        Curr_Emergency->setFont(font);

        verticalLayout->addWidget(Curr_Emergency);

        Emergency_Info = new QTextBrowser(verticalLayoutWidget_2);
        Emergency_Info->setObjectName(QStringLiteral("Emergency_Info"));
        QSizePolicy sizePolicy2(QSizePolicy::Preferred, QSizePolicy::Expanding);
        sizePolicy2.setHorizontalStretch(0);
        sizePolicy2.setVerticalStretch(0);
        sizePolicy2.setHeightForWidth(Emergency_Info->sizePolicy().hasHeightForWidth());
        Emergency_Info->setSizePolicy(sizePolicy2);
        QFont font1;
        font1.setFamily(QStringLiteral("DejaVu Sans"));
        font1.setBold(false);
        font1.setWeight(50);
        Emergency_Info->setFont(font1);

        verticalLayout->addWidget(Emergency_Info);

        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setObjectName(QStringLiteral("horizontalLayout_3"));

        verticalLayout->addLayout(horizontalLayout_3);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));

        verticalLayout->addLayout(horizontalLayout);


        horizontalLayout_2->addLayout(verticalLayout);


        verticalLayout_2->addLayout(horizontalLayout_2);

        horizontalLayout_4 = new QHBoxLayout();
        horizontalLayout_4->setObjectName(QStringLiteral("horizontalLayout_4"));
        Update_Emergency = new QPushButton(verticalLayoutWidget_2);
        Update_Emergency->setObjectName(QStringLiteral("Update_Emergency"));
        QSizePolicy sizePolicy3(QSizePolicy::Preferred, QSizePolicy::Fixed);
        sizePolicy3.setHorizontalStretch(0);
        sizePolicy3.setVerticalStretch(0);
        sizePolicy3.setHeightForWidth(Update_Emergency->sizePolicy().hasHeightForWidth());
        Update_Emergency->setSizePolicy(sizePolicy3);
        Update_Emergency->setStyleSheet(QStringLiteral("background-color: rgb(114, 159, 207);"));

        horizontalLayout_4->addWidget(Update_Emergency);

        Report_Emergency = new QPushButton(verticalLayoutWidget_2);
        Report_Emergency->setObjectName(QStringLiteral("Report_Emergency"));
        sizePolicy3.setHeightForWidth(Report_Emergency->sizePolicy().hasHeightForWidth());
        Report_Emergency->setSizePolicy(sizePolicy3);
        Report_Emergency->setStyleSheet(QStringLiteral("background-color: rgb(114, 159, 207);"));

        horizontalLayout_4->addWidget(Report_Emergency);

        Chat_Page = new QPushButton(verticalLayoutWidget_2);
        Chat_Page->setObjectName(QStringLiteral("Chat_Page"));
        sizePolicy1.setHeightForWidth(Chat_Page->sizePolicy().hasHeightForWidth());
        Chat_Page->setSizePolicy(sizePolicy1);
        Chat_Page->setStyleSheet(QStringLiteral("background-color: rgb(114, 159, 207);"));

        horizontalLayout_4->addWidget(Chat_Page);

        User_Center = new QPushButton(verticalLayoutWidget_2);
        User_Center->setObjectName(QStringLiteral("User_Center"));
        sizePolicy1.setHeightForWidth(User_Center->sizePolicy().hasHeightForWidth());
        User_Center->setSizePolicy(sizePolicy1);
        User_Center->setStyleSheet(QStringLiteral("background-color: rgb(114, 159, 207);"));

        horizontalLayout_4->addWidget(User_Center);


        verticalLayout_2->addLayout(horizontalLayout_4);

        verticalLayout_3 = new QVBoxLayout();
        verticalLayout_3->setObjectName(QStringLiteral("verticalLayout_3"));

        verticalLayout_2->addLayout(verticalLayout_3);


        retranslateUi(responderCurrEm);

        QMetaObject::connectSlotsByName(responderCurrEm);
    } // setupUi

    void retranslateUi(QWidget *responderCurrEm)
    {
        responderCurrEm->setWindowTitle(QApplication::translate("responderCurrEm", "Form", nullptr));
        Curr_Emergency->setText(QApplication::translate("responderCurrEm", "Current Emergency", nullptr));
        Emergency_Info->setHtml(QApplication::translate("responderCurrEm", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'DejaVu Sans'; font-size:10pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-family:'Sans'; text-decoration: underline;\">Time:</span><span style=\" font-family:'Sans';\"> February 30, 2018, 21:21 pm</span></p>\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:'Sans';\"><br /></p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-family:'Sans'; text-decoration: underline;\">Location:</span><span style=\" font-fami"
                        "ly:'Sans';\"> Acopian Engineering Center</span></p>\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:'Sans';\"><br /></p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-family:'Sans'; text-decoration: underline;\">Instruction:</span><span style=\" font-family:'Sans';\"> Please get out of the building as soon as possible through staircases.</span></p>\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:'Sans';\"><br /></p></body></html>", nullptr));
        Update_Emergency->setText(QApplication::translate("responderCurrEm", "Update Emergency", nullptr));
        Report_Emergency->setText(QApplication::translate("responderCurrEm", "Report Emergency", nullptr));
        Chat_Page->setText(QApplication::translate("responderCurrEm", "Chat Page", nullptr));
        User_Center->setText(QApplication::translate("responderCurrEm", "User center", nullptr));
    } // retranslateUi

};

namespace Ui {
    class responderCurrEm: public Ui_responderCurrEm {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_RESPONDERCURREM_H
