/********************************************************************************
** Form generated from reading UI file 'publicverification.ui'
**
** Created by: Qt User Interface Compiler version 5.10.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_PUBLICVERIFICATION_H
#define UI_PUBLICVERIFICATION_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_PublicVerification
{
public:
    QPushButton *verify;
    QPushButton *cancel;
    QPushButton *submit;

    void setupUi(QWidget *PublicVerification)
    {
        if (PublicVerification->objectName().isEmpty())
            PublicVerification->setObjectName(QStringLiteral("PublicVerification"));
        PublicVerification->resize(900, 600);
        verify = new QPushButton(PublicVerification);
        verify->setObjectName(QStringLiteral("verify"));
        verify->setGeometry(QRect(200, 260, 471, 41));
        verify->setStyleSheet(QStringLiteral("background-color: rgb(239, 41, 41);"));
        cancel = new QPushButton(PublicVerification);
        cancel->setObjectName(QStringLiteral("cancel"));
        cancel->setGeometry(QRect(80, 480, 83, 25));
        cancel->setStyleSheet(QStringLiteral("background-color: rgb(239, 41, 41);"));
        submit = new QPushButton(PublicVerification);
        submit->setObjectName(QStringLiteral("submit"));
        submit->setGeometry(QRect(710, 480, 83, 25));
        submit->setStyleSheet(QStringLiteral("background-color: rgb(239, 41, 41);"));

        retranslateUi(PublicVerification);

        QMetaObject::connectSlotsByName(PublicVerification);
    } // setupUi

    void retranslateUi(QWidget *PublicVerification)
    {
        PublicVerification->setWindowTitle(QApplication::translate("PublicVerification", "Form", nullptr));
        verify->setText(QApplication::translate("PublicVerification", "Verify", nullptr));
        cancel->setText(QApplication::translate("PublicVerification", "Cancel", nullptr));
        submit->setText(QApplication::translate("PublicVerification", "Submit", nullptr));
    } // retranslateUi

};

namespace Ui {
    class PublicVerification: public Ui_PublicVerification {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_PUBLICVERIFICATION_H
