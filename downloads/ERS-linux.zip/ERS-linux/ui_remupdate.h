/********************************************************************************
** Form generated from reading UI file 'remupdate.ui'
**
** Created by: Qt User Interface Compiler version 5.10.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_REMUPDATE_H
#define UI_REMUPDATE_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_rEmUpdate
{
public:
    QTextEdit *updateInfo;
    QPushButton *pushButton;
    QPushButton *pushButton_2;
    QLabel *label;

    void setupUi(QWidget *rEmUpdate)
    {
        if (rEmUpdate->objectName().isEmpty())
            rEmUpdate->setObjectName(QStringLiteral("rEmUpdate"));
        rEmUpdate->resize(900, 600);
        updateInfo = new QTextEdit(rEmUpdate);
        updateInfo->setObjectName(QStringLiteral("updateInfo"));
        updateInfo->setGeometry(QRect(150, 110, 551, 351));
        pushButton = new QPushButton(rEmUpdate);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(100, 490, 83, 25));
        pushButton->setStyleSheet(QStringLiteral("background-color: rgb(114, 159, 207);"));
        pushButton_2 = new QPushButton(rEmUpdate);
        pushButton_2->setObjectName(QStringLiteral("pushButton_2"));
        pushButton_2->setGeometry(QRect(670, 490, 83, 25));
        pushButton_2->setStyleSheet(QStringLiteral("background-color: rgb(114, 159, 207);"));
        label = new QLabel(rEmUpdate);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(160, 80, 121, 17));
        QFont font;
        font.setFamily(QStringLiteral("DejaVu Sans"));
        font.setPointSize(12);
        label->setFont(font);

        retranslateUi(rEmUpdate);

        QMetaObject::connectSlotsByName(rEmUpdate);
    } // setupUi

    void retranslateUi(QWidget *rEmUpdate)
    {
        rEmUpdate->setWindowTitle(QApplication::translate("rEmUpdate", "Form", nullptr));
        pushButton->setText(QApplication::translate("rEmUpdate", "Cancel", nullptr));
        pushButton_2->setText(QApplication::translate("rEmUpdate", "Submit", nullptr));
        label->setText(QApplication::translate("rEmUpdate", "Update Report", nullptr));
    } // retranslateUi

};

namespace Ui {
    class rEmUpdate: public Ui_rEmUpdate {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_REMUPDATE_H
