/********************************************************************************
** Form generated from reading UI file 'curremmap.ui'
**
** Created by: Qt User Interface Compiler version 5.10.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CURREMMAP_H
#define UI_CURREMMAP_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_currEmMap
{
public:

    void setupUi(QWidget *currEmMap)
    {
        if (currEmMap->objectName().isEmpty())
            currEmMap->setObjectName(QStringLiteral("currEmMap"));
        currEmMap->resize(900, 600);

        retranslateUi(currEmMap);

        QMetaObject::connectSlotsByName(currEmMap);
    } // setupUi

    void retranslateUi(QWidget *currEmMap)
    {
        currEmMap->setWindowTitle(QApplication::translate("currEmMap", "Form", nullptr));
    } // retranslateUi

};

namespace Ui {
    class currEmMap: public Ui_currEmMap {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CURREMMAP_H
