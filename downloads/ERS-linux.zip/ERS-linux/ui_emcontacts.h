/********************************************************************************
** Form generated from reading UI file 'emcontacts.ui'
**
** Created by: Qt User Interface Compiler version 5.10.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_EMCONTACTS_H
#define UI_EMCONTACTS_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QListWidget>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>
#include "UI/common/staticmapwidget.h"

QT_BEGIN_NAMESPACE

class Ui_EmContacts
{
public:
    QWidget *horizontalLayoutWidget;
    QHBoxLayout *horizontalLayout;
    QVBoxLayout *verticalLayout;
    QLabel *label;
    QListWidget *listWidget;
    QLineEdit *name;
    QHBoxLayout *horizontalLayout_3;
    QLineEdit *xCood;
    QLineEdit *yCood;
    QPushButton *add;
    QSpacerItem *verticalSpacer;
    QHBoxLayout *horizontalLayout_2;
    QLineEdit *index;
    QPushButton *remove;
    QPushButton *back;
    staticMapWidget *staticMap;

    void setupUi(QWidget *EmContacts)
    {
        if (EmContacts->objectName().isEmpty())
            EmContacts->setObjectName(QStringLiteral("EmContacts"));
        EmContacts->resize(900, 600);
        horizontalLayoutWidget = new QWidget(EmContacts);
        horizontalLayoutWidget->setObjectName(QStringLiteral("horizontalLayoutWidget"));
        horizontalLayoutWidget->setGeometry(QRect(10, 10, 881, 581));
        horizontalLayout = new QHBoxLayout(horizontalLayoutWidget);
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        horizontalLayout->setContentsMargins(0, 0, 0, 0);
        verticalLayout = new QVBoxLayout();
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        label = new QLabel(horizontalLayoutWidget);
        label->setObjectName(QStringLiteral("label"));

        verticalLayout->addWidget(label);

        listWidget = new QListWidget(horizontalLayoutWidget);
        listWidget->setObjectName(QStringLiteral("listWidget"));
        QSizePolicy sizePolicy(QSizePolicy::Preferred, QSizePolicy::Expanding);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(listWidget->sizePolicy().hasHeightForWidth());
        listWidget->setSizePolicy(sizePolicy);

        verticalLayout->addWidget(listWidget);

        name = new QLineEdit(horizontalLayoutWidget);
        name->setObjectName(QStringLiteral("name"));
        QSizePolicy sizePolicy1(QSizePolicy::Preferred, QSizePolicy::Fixed);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(name->sizePolicy().hasHeightForWidth());
        name->setSizePolicy(sizePolicy1);

        verticalLayout->addWidget(name);

        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setObjectName(QStringLiteral("horizontalLayout_3"));
        xCood = new QLineEdit(horizontalLayoutWidget);
        xCood->setObjectName(QStringLiteral("xCood"));
        sizePolicy1.setHeightForWidth(xCood->sizePolicy().hasHeightForWidth());
        xCood->setSizePolicy(sizePolicy1);

        horizontalLayout_3->addWidget(xCood);

        yCood = new QLineEdit(horizontalLayoutWidget);
        yCood->setObjectName(QStringLiteral("yCood"));
        sizePolicy1.setHeightForWidth(yCood->sizePolicy().hasHeightForWidth());
        yCood->setSizePolicy(sizePolicy1);

        horizontalLayout_3->addWidget(yCood);

        add = new QPushButton(horizontalLayoutWidget);
        add->setObjectName(QStringLiteral("add"));
        add->setStyleSheet(QStringLiteral("background-color: rgb(239, 41, 41);"));

        horizontalLayout_3->addWidget(add);


        verticalLayout->addLayout(horizontalLayout_3);

        verticalSpacer = new QSpacerItem(20, 5, QSizePolicy::Minimum, QSizePolicy::Minimum);

        verticalLayout->addItem(verticalSpacer);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName(QStringLiteral("horizontalLayout_2"));
        index = new QLineEdit(horizontalLayoutWidget);
        index->setObjectName(QStringLiteral("index"));
        sizePolicy1.setHeightForWidth(index->sizePolicy().hasHeightForWidth());
        index->setSizePolicy(sizePolicy1);

        horizontalLayout_2->addWidget(index);

        remove = new QPushButton(horizontalLayoutWidget);
        remove->setObjectName(QStringLiteral("remove"));
        remove->setStyleSheet(QStringLiteral("background-color: rgb(239, 41, 41);"));

        horizontalLayout_2->addWidget(remove);


        verticalLayout->addLayout(horizontalLayout_2);

        back = new QPushButton(horizontalLayoutWidget);
        back->setObjectName(QStringLiteral("back"));
        back->setStyleSheet(QStringLiteral("background-color: rgb(239, 41, 41);"));

        verticalLayout->addWidget(back);


        horizontalLayout->addLayout(verticalLayout);

        staticMap = new staticMapWidget(horizontalLayoutWidget);
        staticMap->setObjectName(QStringLiteral("staticMap"));
        QSizePolicy sizePolicy2(QSizePolicy::Expanding, QSizePolicy::Preferred);
        sizePolicy2.setHorizontalStretch(0);
        sizePolicy2.setVerticalStretch(0);
        sizePolicy2.setHeightForWidth(staticMap->sizePolicy().hasHeightForWidth());
        staticMap->setSizePolicy(sizePolicy2);

        horizontalLayout->addWidget(staticMap);


        retranslateUi(EmContacts);

        QMetaObject::connectSlotsByName(EmContacts);
    } // setupUi

    void retranslateUi(QWidget *EmContacts)
    {
        EmContacts->setWindowTitle(QApplication::translate("EmContacts", "Form", nullptr));
        label->setText(QApplication::translate("EmContacts", "Your emergency contacts:", nullptr));
        name->setPlaceholderText(QApplication::translate("EmContacts", "Name", nullptr));
        xCood->setPlaceholderText(QApplication::translate("EmContacts", "x", nullptr));
        yCood->setPlaceholderText(QApplication::translate("EmContacts", "y", nullptr));
        add->setText(QApplication::translate("EmContacts", "Add", nullptr));
        index->setPlaceholderText(QApplication::translate("EmContacts", "index", nullptr));
        remove->setText(QApplication::translate("EmContacts", "Remove", nullptr));
        back->setText(QApplication::translate("EmContacts", "Back", nullptr));
    } // retranslateUi

};

namespace Ui {
    class EmContacts: public Ui_EmContacts {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_EMCONTACTS_H
