/********************************************************************************
** Form generated from reading UI file 'specialverification.ui'
**
** Created by: Qt User Interface Compiler version 5.10.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SPECIALVERIFICATION_H
#define UI_SPECIALVERIFICATION_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_SpecialVerification
{
public:
    QPushButton *verify;
    QPushButton *cancel;
    QPushButton *pushButton_2;

    void setupUi(QWidget *SpecialVerification)
    {
        if (SpecialVerification->objectName().isEmpty())
            SpecialVerification->setObjectName(QStringLiteral("SpecialVerification"));
        SpecialVerification->resize(900, 600);
        verify = new QPushButton(SpecialVerification);
        verify->setObjectName(QStringLiteral("verify"));
        verify->setGeometry(QRect(220, 230, 451, 41));
        verify->setStyleSheet(QStringLiteral("background-color: rgb(114, 159, 207);"));
        cancel = new QPushButton(SpecialVerification);
        cancel->setObjectName(QStringLiteral("cancel"));
        cancel->setGeometry(QRect(70, 510, 83, 25));
        cancel->setStyleSheet(QStringLiteral("background-color: rgb(114, 159, 207);"));
        pushButton_2 = new QPushButton(SpecialVerification);
        pushButton_2->setObjectName(QStringLiteral("pushButton_2"));
        pushButton_2->setGeometry(QRect(750, 510, 83, 25));
        pushButton_2->setStyleSheet(QStringLiteral("background-color: rgb(114, 159, 207);"));

        retranslateUi(SpecialVerification);

        QMetaObject::connectSlotsByName(SpecialVerification);
    } // setupUi

    void retranslateUi(QWidget *SpecialVerification)
    {
        SpecialVerification->setWindowTitle(QApplication::translate("SpecialVerification", "Form", nullptr));
        verify->setText(QApplication::translate("SpecialVerification", "Verify", nullptr));
        cancel->setText(QApplication::translate("SpecialVerification", "Cancel", nullptr));
        pushButton_2->setText(QApplication::translate("SpecialVerification", "Submit", nullptr));
    } // retranslateUi

};

namespace Ui {
    class SpecialVerification: public Ui_SpecialVerification {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SPECIALVERIFICATION_H
