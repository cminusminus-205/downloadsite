/********************************************************************************
** Form generated from reading UI file 'googlemapdemo.ui'
**
** Created by: Qt User Interface Compiler version 5.10.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_GOOGLEMAPDEMO_H
#define UI_GOOGLEMAPDEMO_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>
#include "UI/common/mapwidget.h"

QT_BEGIN_NAMESPACE

class Ui_GoogleMapDemo
{
public:
    QWidget *verticalLayoutWidget;
    QVBoxLayout *verticalLayout;
    QLabel *label;
    mapWidget *widget;
    QHBoxLayout *horizontalLayout_2;
    QLineEdit *lineEdit_2;
    QLineEdit *lineEdit;
    QPushButton *pushButton_4;
    QHBoxLayout *horizontalLayout_3;
    QLineEdit *lineEdit_3;
    QPushButton *pushButton_5;
    QPushButton *pushButton_6;
    QHBoxLayout *horizontalLayout;
    QPushButton *pushButton_2;
    QPushButton *pushButton;
    QPushButton *pushButton_3;

    void setupUi(QWidget *GoogleMapDemo)
    {
        if (GoogleMapDemo->objectName().isEmpty())
            GoogleMapDemo->setObjectName(QStringLiteral("GoogleMapDemo"));
        GoogleMapDemo->resize(900, 600);
        verticalLayoutWidget = new QWidget(GoogleMapDemo);
        verticalLayoutWidget->setObjectName(QStringLiteral("verticalLayoutWidget"));
        verticalLayoutWidget->setGeometry(QRect(40, 20, 811, 561));
        verticalLayout = new QVBoxLayout(verticalLayoutWidget);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        label = new QLabel(verticalLayoutWidget);
        label->setObjectName(QStringLiteral("label"));
        QFont font;
        font.setFamily(QStringLiteral("DejaVu Sans"));
        font.setPointSize(12);
        label->setFont(font);

        verticalLayout->addWidget(label);

        widget = new mapWidget(verticalLayoutWidget);
        widget->setObjectName(QStringLiteral("widget"));
        QSizePolicy sizePolicy(QSizePolicy::Preferred, QSizePolicy::MinimumExpanding);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(widget->sizePolicy().hasHeightForWidth());
        widget->setSizePolicy(sizePolicy);

        verticalLayout->addWidget(widget);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName(QStringLiteral("horizontalLayout_2"));
        lineEdit_2 = new QLineEdit(verticalLayoutWidget);
        lineEdit_2->setObjectName(QStringLiteral("lineEdit_2"));

        horizontalLayout_2->addWidget(lineEdit_2);

        lineEdit = new QLineEdit(verticalLayoutWidget);
        lineEdit->setObjectName(QStringLiteral("lineEdit"));

        horizontalLayout_2->addWidget(lineEdit);

        pushButton_4 = new QPushButton(verticalLayoutWidget);
        pushButton_4->setObjectName(QStringLiteral("pushButton_4"));

        horizontalLayout_2->addWidget(pushButton_4);


        verticalLayout->addLayout(horizontalLayout_2);

        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setObjectName(QStringLiteral("horizontalLayout_3"));
        lineEdit_3 = new QLineEdit(verticalLayoutWidget);
        lineEdit_3->setObjectName(QStringLiteral("lineEdit_3"));

        horizontalLayout_3->addWidget(lineEdit_3);

        pushButton_5 = new QPushButton(verticalLayoutWidget);
        pushButton_5->setObjectName(QStringLiteral("pushButton_5"));

        horizontalLayout_3->addWidget(pushButton_5);

        pushButton_6 = new QPushButton(verticalLayoutWidget);
        pushButton_6->setObjectName(QStringLiteral("pushButton_6"));

        horizontalLayout_3->addWidget(pushButton_6);


        verticalLayout->addLayout(horizontalLayout_3);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        pushButton_2 = new QPushButton(verticalLayoutWidget);
        pushButton_2->setObjectName(QStringLiteral("pushButton_2"));

        horizontalLayout->addWidget(pushButton_2);

        pushButton = new QPushButton(verticalLayoutWidget);
        pushButton->setObjectName(QStringLiteral("pushButton"));

        horizontalLayout->addWidget(pushButton);

        pushButton_3 = new QPushButton(verticalLayoutWidget);
        pushButton_3->setObjectName(QStringLiteral("pushButton_3"));

        horizontalLayout->addWidget(pushButton_3);


        verticalLayout->addLayout(horizontalLayout);


        retranslateUi(GoogleMapDemo);
        QObject::connect(lineEdit_2, SIGNAL(textEdited(QString)), widget, SLOT(updateXSlot(QString)));
        QObject::connect(lineEdit, SIGNAL(textEdited(QString)), widget, SLOT(updateYSlot(QString)));
        QObject::connect(pushButton_4, SIGNAL(clicked()), widget, SLOT(reloadMapSlot()));
        QObject::connect(lineEdit_3, SIGNAL(textEdited(QString)), widget, SLOT(updateSearchSlot(QString)));
        QObject::connect(pushButton_5, SIGNAL(clicked()), widget, SLOT(reloadMapSearchSlot()));
        QObject::connect(pushButton_6, SIGNAL(clicked()), widget, SLOT(resetMapSlot()));

        QMetaObject::connectSlotsByName(GoogleMapDemo);
    } // setupUi

    void retranslateUi(QWidget *GoogleMapDemo)
    {
        GoogleMapDemo->setWindowTitle(QApplication::translate("GoogleMapDemo", "Form", nullptr));
        label->setText(QApplication::translate("GoogleMapDemo", "Current Emergency", nullptr));
        lineEdit_2->setPlaceholderText(QApplication::translate("GoogleMapDemo", "X", nullptr));
        lineEdit->setPlaceholderText(QApplication::translate("GoogleMapDemo", "Y", nullptr));
        pushButton_4->setText(QApplication::translate("GoogleMapDemo", "Go!", nullptr));
        lineEdit_3->setPlaceholderText(QApplication::translate("GoogleMapDemo", "Enter location", nullptr));
        pushButton_5->setText(QApplication::translate("GoogleMapDemo", "Search!", nullptr));
        pushButton_6->setText(QApplication::translate("GoogleMapDemo", "Where am I", nullptr));
        pushButton_2->setText(QApplication::translate("GoogleMapDemo", "Report Emergency", nullptr));
        pushButton->setText(QApplication::translate("GoogleMapDemo", "Current Emergency", nullptr));
        pushButton_3->setText(QApplication::translate("GoogleMapDemo", "User center", nullptr));
    } // retranslateUi

};

namespace Ui {
    class GoogleMapDemo: public Ui_GoogleMapDemo {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_GOOGLEMAPDEMO_H
