/********************************************************************************
** Form generated from reading UI file 'userinfo.ui'
**
** Created by: Qt User Interface Compiler version 5.10.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_USERINFO_H
#define UI_USERINFO_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QRadioButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_userinfo
{
public:
    QWidget *verticalLayoutWidget_2;
    QVBoxLayout *verticalLayout_3;
    QSpacerItem *verticalSpacer_2;
    QHBoxLayout *horizontalLayout_4;
    QSpacerItem *horizontalSpacer;
    QVBoxLayout *verticalLayout_2;
    QHBoxLayout *horizontalLayout_2;
    QLineEdit *Home;
    QLineEdit *HomeZip;
    QHBoxLayout *horizontalLayout;
    QLineEdit *Work;
    QLineEdit *WorkZip;
    QLabel *I_am_a;
    QVBoxLayout *verticalLayout;
    QRadioButton *Gen_Pub;
    QRadioButton *First_Res;
    QRadioButton *Control_Center;
    QLabel *Choose;
    QGridLayout *gridLayout;
    QCheckBox *bicycle;
    QCheckBox *plane;
    QCheckBox *walk;
    QCheckBox *subway;
    QCheckBox *railway;
    QCheckBox *ferry;
    QCheckBox *bus;
    QCheckBox *vehicle;
    QLabel *lable;
    QHBoxLayout *horizontalLayout_3;
    QPushButton *Cancel;
    QSpacerItem *horizontalSpacer_3;
    QPushButton *Finish;
    QSpacerItem *horizontalSpacer_2;
    QSpacerItem *verticalSpacer;

    void setupUi(QWidget *userinfo)
    {
        if (userinfo->objectName().isEmpty())
            userinfo->setObjectName(QStringLiteral("userinfo"));
        userinfo->resize(900, 600);
        QPalette palette;
        QBrush brush(QColor(0, 0, 0, 255));
        brush.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::WindowText, brush);
        QBrush brush1(QColor(239, 41, 41, 255));
        brush1.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::Button, brush1);
        QBrush brush2(QColor(255, 147, 147, 255));
        brush2.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::Light, brush2);
        QBrush brush3(QColor(247, 94, 94, 255));
        brush3.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::Midlight, brush3);
        QBrush brush4(QColor(119, 20, 20, 255));
        brush4.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::Dark, brush4);
        QBrush brush5(QColor(159, 27, 27, 255));
        brush5.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::Mid, brush5);
        palette.setBrush(QPalette::Active, QPalette::Text, brush);
        QBrush brush6(QColor(255, 255, 255, 255));
        brush6.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::BrightText, brush6);
        palette.setBrush(QPalette::Active, QPalette::ButtonText, brush);
        palette.setBrush(QPalette::Active, QPalette::Base, brush6);
        QBrush brush7(QColor(238, 238, 236, 255));
        brush7.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::Window, brush7);
        palette.setBrush(QPalette::Active, QPalette::Shadow, brush);
        QBrush brush8(QColor(247, 148, 148, 255));
        brush8.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::AlternateBase, brush8);
        QBrush brush9(QColor(255, 255, 220, 255));
        brush9.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::ToolTipBase, brush9);
        palette.setBrush(QPalette::Active, QPalette::ToolTipText, brush);
        palette.setBrush(QPalette::Inactive, QPalette::WindowText, brush);
        palette.setBrush(QPalette::Inactive, QPalette::Button, brush1);
        palette.setBrush(QPalette::Inactive, QPalette::Light, brush2);
        palette.setBrush(QPalette::Inactive, QPalette::Midlight, brush3);
        palette.setBrush(QPalette::Inactive, QPalette::Dark, brush4);
        palette.setBrush(QPalette::Inactive, QPalette::Mid, brush5);
        palette.setBrush(QPalette::Inactive, QPalette::Text, brush);
        palette.setBrush(QPalette::Inactive, QPalette::BrightText, brush6);
        palette.setBrush(QPalette::Inactive, QPalette::ButtonText, brush);
        palette.setBrush(QPalette::Inactive, QPalette::Base, brush6);
        palette.setBrush(QPalette::Inactive, QPalette::Window, brush7);
        palette.setBrush(QPalette::Inactive, QPalette::Shadow, brush);
        palette.setBrush(QPalette::Inactive, QPalette::AlternateBase, brush8);
        palette.setBrush(QPalette::Inactive, QPalette::ToolTipBase, brush9);
        palette.setBrush(QPalette::Inactive, QPalette::ToolTipText, brush);
        palette.setBrush(QPalette::Disabled, QPalette::WindowText, brush4);
        palette.setBrush(QPalette::Disabled, QPalette::Button, brush1);
        palette.setBrush(QPalette::Disabled, QPalette::Light, brush2);
        palette.setBrush(QPalette::Disabled, QPalette::Midlight, brush3);
        palette.setBrush(QPalette::Disabled, QPalette::Dark, brush4);
        palette.setBrush(QPalette::Disabled, QPalette::Mid, brush5);
        palette.setBrush(QPalette::Disabled, QPalette::Text, brush4);
        palette.setBrush(QPalette::Disabled, QPalette::BrightText, brush6);
        palette.setBrush(QPalette::Disabled, QPalette::ButtonText, brush4);
        palette.setBrush(QPalette::Disabled, QPalette::Base, brush7);
        palette.setBrush(QPalette::Disabled, QPalette::Window, brush7);
        palette.setBrush(QPalette::Disabled, QPalette::Shadow, brush);
        palette.setBrush(QPalette::Disabled, QPalette::AlternateBase, brush1);
        palette.setBrush(QPalette::Disabled, QPalette::ToolTipBase, brush9);
        palette.setBrush(QPalette::Disabled, QPalette::ToolTipText, brush);
        userinfo->setPalette(palette);
        QFont font;
        font.setFamily(QStringLiteral("DejaVu Sans"));
        font.setBold(false);
        font.setWeight(50);
        userinfo->setFont(font);
        verticalLayoutWidget_2 = new QWidget(userinfo);
        verticalLayoutWidget_2->setObjectName(QStringLiteral("verticalLayoutWidget_2"));
        verticalLayoutWidget_2->setGeometry(QRect(10, 10, 881, 581));
        verticalLayout_3 = new QVBoxLayout(verticalLayoutWidget_2);
        verticalLayout_3->setObjectName(QStringLiteral("verticalLayout_3"));
        verticalLayout_3->setContentsMargins(0, 0, 0, 0);
        verticalSpacer_2 = new QSpacerItem(20, 38, QSizePolicy::Minimum, QSizePolicy::Fixed);

        verticalLayout_3->addItem(verticalSpacer_2);

        horizontalLayout_4 = new QHBoxLayout();
        horizontalLayout_4->setObjectName(QStringLiteral("horizontalLayout_4"));
        horizontalSpacer = new QSpacerItem(150, 20, QSizePolicy::Fixed, QSizePolicy::Minimum);

        horizontalLayout_4->addItem(horizontalSpacer);

        verticalLayout_2 = new QVBoxLayout();
        verticalLayout_2->setObjectName(QStringLiteral("verticalLayout_2"));
        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName(QStringLiteral("horizontalLayout_2"));
        Home = new QLineEdit(verticalLayoutWidget_2);
        Home->setObjectName(QStringLiteral("Home"));

        horizontalLayout_2->addWidget(Home);

        HomeZip = new QLineEdit(verticalLayoutWidget_2);
        HomeZip->setObjectName(QStringLiteral("HomeZip"));

        horizontalLayout_2->addWidget(HomeZip);


        verticalLayout_2->addLayout(horizontalLayout_2);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        Work = new QLineEdit(verticalLayoutWidget_2);
        Work->setObjectName(QStringLiteral("Work"));

        horizontalLayout->addWidget(Work);

        WorkZip = new QLineEdit(verticalLayoutWidget_2);
        WorkZip->setObjectName(QStringLiteral("WorkZip"));

        horizontalLayout->addWidget(WorkZip);


        verticalLayout_2->addLayout(horizontalLayout);

        I_am_a = new QLabel(verticalLayoutWidget_2);
        I_am_a->setObjectName(QStringLiteral("I_am_a"));
        QFont font1;
        font1.setPointSize(11);
        I_am_a->setFont(font1);

        verticalLayout_2->addWidget(I_am_a);

        verticalLayout = new QVBoxLayout();
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        Gen_Pub = new QRadioButton(verticalLayoutWidget_2);
        Gen_Pub->setObjectName(QStringLiteral("Gen_Pub"));
        Gen_Pub->setChecked(true);

        verticalLayout->addWidget(Gen_Pub);

        First_Res = new QRadioButton(verticalLayoutWidget_2);
        First_Res->setObjectName(QStringLiteral("First_Res"));

        verticalLayout->addWidget(First_Res);

        Control_Center = new QRadioButton(verticalLayoutWidget_2);
        Control_Center->setObjectName(QStringLiteral("Control_Center"));

        verticalLayout->addWidget(Control_Center);


        verticalLayout_2->addLayout(verticalLayout);

        Choose = new QLabel(verticalLayoutWidget_2);
        Choose->setObjectName(QStringLiteral("Choose"));
        Choose->setFont(font1);

        verticalLayout_2->addWidget(Choose);

        gridLayout = new QGridLayout();
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        bicycle = new QCheckBox(verticalLayoutWidget_2);
        bicycle->setObjectName(QStringLiteral("bicycle"));
        bicycle->setChecked(true);

        gridLayout->addWidget(bicycle, 2, 1, 1, 1);

        plane = new QCheckBox(verticalLayoutWidget_2);
        plane->setObjectName(QStringLiteral("plane"));
        plane->setChecked(true);

        gridLayout->addWidget(plane, 3, 1, 1, 1);

        walk = new QCheckBox(verticalLayoutWidget_2);
        walk->setObjectName(QStringLiteral("walk"));
        walk->setChecked(true);

        gridLayout->addWidget(walk, 0, 0, 1, 1);

        subway = new QCheckBox(verticalLayoutWidget_2);
        subway->setObjectName(QStringLiteral("subway"));
        subway->setChecked(true);

        gridLayout->addWidget(subway, 3, 0, 1, 1);

        railway = new QCheckBox(verticalLayoutWidget_2);
        railway->setObjectName(QStringLiteral("railway"));
        railway->setChecked(true);

        gridLayout->addWidget(railway, 2, 0, 1, 1);

        ferry = new QCheckBox(verticalLayoutWidget_2);
        ferry->setObjectName(QStringLiteral("ferry"));
        ferry->setChecked(true);

        gridLayout->addWidget(ferry, 1, 1, 1, 1);

        bus = new QCheckBox(verticalLayoutWidget_2);
        bus->setObjectName(QStringLiteral("bus"));
        bus->setChecked(true);

        gridLayout->addWidget(bus, 1, 0, 1, 1);

        vehicle = new QCheckBox(verticalLayoutWidget_2);
        vehicle->setObjectName(QStringLiteral("vehicle"));
        vehicle->setChecked(true);

        gridLayout->addWidget(vehicle, 0, 1, 1, 1);


        verticalLayout_2->addLayout(gridLayout);

        lable = new QLabel(verticalLayoutWidget_2);
        lable->setObjectName(QStringLiteral("lable"));
        QFont font2;
        font2.setFamily(QStringLiteral("DejaVu Sans Mono"));
        font2.setPointSize(9);
        font2.setItalic(true);
        lable->setFont(font2);

        verticalLayout_2->addWidget(lable);

        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setObjectName(QStringLiteral("horizontalLayout_3"));
        Cancel = new QPushButton(verticalLayoutWidget_2);
        Cancel->setObjectName(QStringLiteral("Cancel"));
        Cancel->setStyleSheet(QStringLiteral("background-color: rgb(211, 215, 207);"));

        horizontalLayout_3->addWidget(Cancel);

        horizontalSpacer_3 = new QSpacerItem(80, 20, QSizePolicy::Fixed, QSizePolicy::Minimum);

        horizontalLayout_3->addItem(horizontalSpacer_3);

        Finish = new QPushButton(verticalLayoutWidget_2);
        Finish->setObjectName(QStringLiteral("Finish"));
        Finish->setStyleSheet(QStringLiteral("background-color: rgb(211, 215, 207);"));

        horizontalLayout_3->addWidget(Finish);


        verticalLayout_2->addLayout(horizontalLayout_3);


        horizontalLayout_4->addLayout(verticalLayout_2);

        horizontalSpacer_2 = new QSpacerItem(150, 20, QSizePolicy::Fixed, QSizePolicy::Minimum);

        horizontalLayout_4->addItem(horizontalSpacer_2);


        verticalLayout_3->addLayout(horizontalLayout_4);

        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Fixed);

        verticalLayout_3->addItem(verticalSpacer);


        retranslateUi(userinfo);

        QMetaObject::connectSlotsByName(userinfo);
    } // setupUi

    void retranslateUi(QWidget *userinfo)
    {
        userinfo->setWindowTitle(QApplication::translate("userinfo", "Form", nullptr));
        Home->setPlaceholderText(QApplication::translate("userinfo", "Home Address", nullptr));
        HomeZip->setText(QString());
        HomeZip->setPlaceholderText(QApplication::translate("userinfo", "Zip Code", nullptr));
        Work->setText(QString());
        Work->setPlaceholderText(QApplication::translate("userinfo", "Work Address", nullptr));
        WorkZip->setText(QString());
        WorkZip->setPlaceholderText(QApplication::translate("userinfo", "Zip Code", nullptr));
        I_am_a->setText(QApplication::translate("userinfo", "I am a...", nullptr));
        Gen_Pub->setText(QApplication::translate("userinfo", "General public", nullptr));
        First_Res->setText(QApplication::translate("userinfo", "First responder", nullptr));
        Control_Center->setText(QApplication::translate("userinfo", "Control center staff", nullptr));
        Choose->setText(QApplication::translate("userinfo", "Choose your ways of transportation:", nullptr));
        bicycle->setText(QApplication::translate("userinfo", "Bicycle", nullptr));
        plane->setText(QApplication::translate("userinfo", "Plane", nullptr));
        walk->setText(QApplication::translate("userinfo", "Walk", nullptr));
        subway->setText(QApplication::translate("userinfo", "Subway", nullptr));
        railway->setText(QApplication::translate("userinfo", "Railway", nullptr));
        ferry->setText(QApplication::translate("userinfo", "Ferry", nullptr));
        bus->setText(QApplication::translate("userinfo", "Bus", nullptr));
        vehicle->setText(QApplication::translate("userinfo", "Private vehicle", nullptr));
        lable->setText(QApplication::translate("userinfo", "It is recommended to check all boxes.", nullptr));
        Cancel->setText(QApplication::translate("userinfo", "Cancel", nullptr));
        Finish->setText(QApplication::translate("userinfo", "Next", nullptr));
    } // retranslateUi

};

namespace Ui {
    class userinfo: public Ui_userinfo {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_USERINFO_H
