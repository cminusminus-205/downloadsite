/********************************************************************************
** Form generated from reading UI file 'verifyem.ui'
**
** Created by: Qt User Interface Compiler version 5.10.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_VERIFYEM_H
#define UI_VERIFYEM_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QTextBrowser>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_verifyEm
{
public:
    QWidget *verticalLayoutWidget;
    QVBoxLayout *verticalLayout_2;
    QSpacerItem *verticalSpacer_2;
    QHBoxLayout *horizontalLayout_2;
    QSpacerItem *horizontalSpacer;
    QHBoxLayout *horizontalLayout;
    QVBoxLayout *verticalLayout;
    QHBoxLayout *horizontalLayout_3;
    QLabel *lebel2;
    QLabel *UserType;
    QLabel *label1;
    QLabel *UserEmail;
    QSpacerItem *verticalSpacer_3;
    QHBoxLayout *horizontalLayout_6;
    QLabel *label5;
    QLabel *type;
    QSpacerItem *verticalSpacer_4;
    QHBoxLayout *horizontalLayout_7;
    QLabel *label6;
    QLabel *location;
    QHBoxLayout *horizontalLayout_8;
    QSpacerItem *verticalSpacer_6;
    QHBoxLayout *horizontalLayout_4;
    QLabel *label4;
    QLabel *date;
    QLabel *label3;
    QLabel *time;
    QSpacerItem *verticalSpacer_7;
    QLabel *Description;
    QTextBrowser *description;
    QSpacerItem *verticalSpacer_8;
    QCheckBox *checkBox;
    QSpacerItem *verticalSpacer_9;
    QHBoxLayout *horizontalLayout_5;
    QPushButton *cancel;
    QSpacerItem *horizontalSpacer_3;
    QPushButton *deny;
    QPushButton *Submit;
    QSpacerItem *horizontalSpacer_2;
    QSpacerItem *verticalSpacer;

    void setupUi(QWidget *verifyEm)
    {
        if (verifyEm->objectName().isEmpty())
            verifyEm->setObjectName(QStringLiteral("verifyEm"));
        verifyEm->resize(900, 600);
        verticalLayoutWidget = new QWidget(verifyEm);
        verticalLayoutWidget->setObjectName(QStringLiteral("verticalLayoutWidget"));
        verticalLayoutWidget->setGeometry(QRect(10, 10, 882, 581));
        verticalLayout_2 = new QVBoxLayout(verticalLayoutWidget);
        verticalLayout_2->setObjectName(QStringLiteral("verticalLayout_2"));
        verticalLayout_2->setContentsMargins(0, 0, 0, 0);
        verticalSpacer_2 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_2->addItem(verticalSpacer_2);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName(QStringLiteral("horizontalLayout_2"));
        horizontalSpacer = new QSpacerItem(200, 20, QSizePolicy::Fixed, QSizePolicy::Minimum);

        horizontalLayout_2->addItem(horizontalSpacer);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        verticalLayout = new QVBoxLayout();
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setObjectName(QStringLiteral("horizontalLayout_3"));
        lebel2 = new QLabel(verticalLayoutWidget);
        lebel2->setObjectName(QStringLiteral("lebel2"));
        QSizePolicy sizePolicy(QSizePolicy::Fixed, QSizePolicy::Preferred);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(lebel2->sizePolicy().hasHeightForWidth());
        lebel2->setSizePolicy(sizePolicy);

        horizontalLayout_3->addWidget(lebel2);

        UserType = new QLabel(verticalLayoutWidget);
        UserType->setObjectName(QStringLiteral("UserType"));

        horizontalLayout_3->addWidget(UserType);

        label1 = new QLabel(verticalLayoutWidget);
        label1->setObjectName(QStringLiteral("label1"));
        sizePolicy.setHeightForWidth(label1->sizePolicy().hasHeightForWidth());
        label1->setSizePolicy(sizePolicy);
        QFont font;
        font.setFamily(QStringLiteral("DejaVu Sans"));
        font.setBold(false);
        font.setWeight(50);
        label1->setFont(font);

        horizontalLayout_3->addWidget(label1);

        UserEmail = new QLabel(verticalLayoutWidget);
        UserEmail->setObjectName(QStringLiteral("UserEmail"));

        horizontalLayout_3->addWidget(UserEmail);


        verticalLayout->addLayout(horizontalLayout_3);

        verticalSpacer_3 = new QSpacerItem(20, 10, QSizePolicy::Minimum, QSizePolicy::Fixed);

        verticalLayout->addItem(verticalSpacer_3);

        horizontalLayout_6 = new QHBoxLayout();
        horizontalLayout_6->setObjectName(QStringLiteral("horizontalLayout_6"));
        label5 = new QLabel(verticalLayoutWidget);
        label5->setObjectName(QStringLiteral("label5"));
        sizePolicy.setHeightForWidth(label5->sizePolicy().hasHeightForWidth());
        label5->setSizePolicy(sizePolicy);

        horizontalLayout_6->addWidget(label5);

        type = new QLabel(verticalLayoutWidget);
        type->setObjectName(QStringLiteral("type"));

        horizontalLayout_6->addWidget(type);


        verticalLayout->addLayout(horizontalLayout_6);

        verticalSpacer_4 = new QSpacerItem(20, 10, QSizePolicy::Minimum, QSizePolicy::Fixed);

        verticalLayout->addItem(verticalSpacer_4);

        horizontalLayout_7 = new QHBoxLayout();
        horizontalLayout_7->setObjectName(QStringLiteral("horizontalLayout_7"));
        label6 = new QLabel(verticalLayoutWidget);
        label6->setObjectName(QStringLiteral("label6"));
        sizePolicy.setHeightForWidth(label6->sizePolicy().hasHeightForWidth());
        label6->setSizePolicy(sizePolicy);

        horizontalLayout_7->addWidget(label6);

        location = new QLabel(verticalLayoutWidget);
        location->setObjectName(QStringLiteral("location"));

        horizontalLayout_7->addWidget(location);


        verticalLayout->addLayout(horizontalLayout_7);

        horizontalLayout_8 = new QHBoxLayout();
        horizontalLayout_8->setObjectName(QStringLiteral("horizontalLayout_8"));

        verticalLayout->addLayout(horizontalLayout_8);

        verticalSpacer_6 = new QSpacerItem(20, 10, QSizePolicy::Minimum, QSizePolicy::Fixed);

        verticalLayout->addItem(verticalSpacer_6);

        horizontalLayout_4 = new QHBoxLayout();
        horizontalLayout_4->setObjectName(QStringLiteral("horizontalLayout_4"));
        label4 = new QLabel(verticalLayoutWidget);
        label4->setObjectName(QStringLiteral("label4"));
        sizePolicy.setHeightForWidth(label4->sizePolicy().hasHeightForWidth());
        label4->setSizePolicy(sizePolicy);

        horizontalLayout_4->addWidget(label4);

        date = new QLabel(verticalLayoutWidget);
        date->setObjectName(QStringLiteral("date"));

        horizontalLayout_4->addWidget(date);

        label3 = new QLabel(verticalLayoutWidget);
        label3->setObjectName(QStringLiteral("label3"));
        sizePolicy.setHeightForWidth(label3->sizePolicy().hasHeightForWidth());
        label3->setSizePolicy(sizePolicy);

        horizontalLayout_4->addWidget(label3);

        time = new QLabel(verticalLayoutWidget);
        time->setObjectName(QStringLiteral("time"));

        horizontalLayout_4->addWidget(time);


        verticalLayout->addLayout(horizontalLayout_4);

        verticalSpacer_7 = new QSpacerItem(20, 10, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout->addItem(verticalSpacer_7);

        Description = new QLabel(verticalLayoutWidget);
        Description->setObjectName(QStringLiteral("Description"));

        verticalLayout->addWidget(Description);

        description = new QTextBrowser(verticalLayoutWidget);
        description->setObjectName(QStringLiteral("description"));

        verticalLayout->addWidget(description);

        verticalSpacer_8 = new QSpacerItem(20, 10, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout->addItem(verticalSpacer_8);

        checkBox = new QCheckBox(verticalLayoutWidget);
        checkBox->setObjectName(QStringLiteral("checkBox"));

        verticalLayout->addWidget(checkBox);

        verticalSpacer_9 = new QSpacerItem(20, 10, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout->addItem(verticalSpacer_9);

        horizontalLayout_5 = new QHBoxLayout();
        horizontalLayout_5->setObjectName(QStringLiteral("horizontalLayout_5"));
        cancel = new QPushButton(verticalLayoutWidget);
        cancel->setObjectName(QStringLiteral("cancel"));
        cancel->setStyleSheet(QStringLiteral("background-color: rgb(252, 233, 79);"));

        horizontalLayout_5->addWidget(cancel);

        horizontalSpacer_3 = new QSpacerItem(80, 20, QSizePolicy::Fixed, QSizePolicy::Minimum);

        horizontalLayout_5->addItem(horizontalSpacer_3);

        deny = new QPushButton(verticalLayoutWidget);
        deny->setObjectName(QStringLiteral("deny"));
        deny->setStyleSheet(QStringLiteral("background-color: rgb(252, 233, 79);"));

        horizontalLayout_5->addWidget(deny);

        Submit = new QPushButton(verticalLayoutWidget);
        Submit->setObjectName(QStringLiteral("Submit"));
        Submit->setStyleSheet(QStringLiteral("background-color: rgb(252, 233, 79);"));

        horizontalLayout_5->addWidget(Submit);


        verticalLayout->addLayout(horizontalLayout_5);


        horizontalLayout->addLayout(verticalLayout);


        horizontalLayout_2->addLayout(horizontalLayout);

        horizontalSpacer_2 = new QSpacerItem(200, 20, QSizePolicy::Fixed, QSizePolicy::Minimum);

        horizontalLayout_2->addItem(horizontalSpacer_2);


        verticalLayout_2->addLayout(horizontalLayout_2);

        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_2->addItem(verticalSpacer);


        retranslateUi(verifyEm);

        QMetaObject::connectSlotsByName(verifyEm);
    } // setupUi

    void retranslateUi(QWidget *verifyEm)
    {
        verifyEm->setWindowTitle(QApplication::translate("verifyEm", "Form", nullptr));
        lebel2->setText(QApplication::translate("verifyEm", "User type: ", nullptr));
        UserType->setText(QString());
        label1->setText(QApplication::translate("verifyEm", "User email:", nullptr));
        UserEmail->setText(QString());
        label5->setText(QApplication::translate("verifyEm", "Type: ", nullptr));
        type->setText(QString());
        label6->setText(QApplication::translate("verifyEm", "Location: ", nullptr));
        location->setText(QString());
        label4->setText(QApplication::translate("verifyEm", "Date: ", nullptr));
        date->setText(QString());
        label3->setText(QApplication::translate("verifyEm", "Time: ", nullptr));
        time->setText(QString());
        Description->setText(QApplication::translate("verifyEm", "Description", nullptr));
        checkBox->setText(QApplication::translate("verifyEm", "I understand my responsibility for the emergency I verify / deny.", nullptr));
        cancel->setText(QApplication::translate("verifyEm", "Back", nullptr));
        deny->setText(QApplication::translate("verifyEm", "Deny", nullptr));
        Submit->setText(QApplication::translate("verifyEm", "Permit", nullptr));
    } // retranslateUi

};

namespace Ui {
    class verifyEm: public Ui_verifyEm {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_VERIFYEM_H
