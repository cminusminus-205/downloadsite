/********************************************************************************
** Form generated from reading UI file 'emerlisttab.ui'
**
** Created by: Qt User Interface Compiler version 5.10.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_EMERLISTTAB_H
#define UI_EMERLISTTAB_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>
#include "UI/common/mapwidget.h"

QT_BEGIN_NAMESPACE

class Ui_emerlisttab
{
public:
    QWidget *horizontalLayoutWidget_2;
    QHBoxLayout *horizontalLayout_2;
    QLabel *emerID;
    QLabel *emerTime;
    QLabel *emerCoord;
    QWidget *verticalLayoutWidget_2;
    QVBoxLayout *verticalLayout_2;
    QHBoxLayout *horizontalLayout_3;
    QLabel *label_4;
    QLabel *responderNum;
    QHBoxLayout *horizontalLayout_4;
    QLabel *label_6;
    QLabel *publicNum;
    QHBoxLayout *horizontalLayout_5;
    QLabel *label_8;
    QLabel *updateNum;
    mapWidget *widget;

    void setupUi(QWidget *emerlisttab)
    {
        if (emerlisttab->objectName().isEmpty())
            emerlisttab->setObjectName(QStringLiteral("emerlisttab"));
        emerlisttab->resize(800, 490);
        horizontalLayoutWidget_2 = new QWidget(emerlisttab);
        horizontalLayoutWidget_2->setObjectName(QStringLiteral("horizontalLayoutWidget_2"));
        horizontalLayoutWidget_2->setGeometry(QRect(10, 10, 781, 41));
        horizontalLayout_2 = new QHBoxLayout(horizontalLayoutWidget_2);
        horizontalLayout_2->setObjectName(QStringLiteral("horizontalLayout_2"));
        horizontalLayout_2->setContentsMargins(0, 0, 0, 0);
        emerID = new QLabel(horizontalLayoutWidget_2);
        emerID->setObjectName(QStringLiteral("emerID"));

        horizontalLayout_2->addWidget(emerID);

        emerTime = new QLabel(horizontalLayoutWidget_2);
        emerTime->setObjectName(QStringLiteral("emerTime"));

        horizontalLayout_2->addWidget(emerTime);

        emerCoord = new QLabel(horizontalLayoutWidget_2);
        emerCoord->setObjectName(QStringLiteral("emerCoord"));

        horizontalLayout_2->addWidget(emerCoord);

        verticalLayoutWidget_2 = new QWidget(emerlisttab);
        verticalLayoutWidget_2->setObjectName(QStringLiteral("verticalLayoutWidget_2"));
        verticalLayoutWidget_2->setGeometry(QRect(560, 60, 231, 151));
        verticalLayout_2 = new QVBoxLayout(verticalLayoutWidget_2);
        verticalLayout_2->setObjectName(QStringLiteral("verticalLayout_2"));
        verticalLayout_2->setContentsMargins(0, 0, 0, 0);
        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setObjectName(QStringLiteral("horizontalLayout_3"));
        label_4 = new QLabel(verticalLayoutWidget_2);
        label_4->setObjectName(QStringLiteral("label_4"));

        horizontalLayout_3->addWidget(label_4);

        responderNum = new QLabel(verticalLayoutWidget_2);
        responderNum->setObjectName(QStringLiteral("responderNum"));

        horizontalLayout_3->addWidget(responderNum);


        verticalLayout_2->addLayout(horizontalLayout_3);

        horizontalLayout_4 = new QHBoxLayout();
        horizontalLayout_4->setObjectName(QStringLiteral("horizontalLayout_4"));
        label_6 = new QLabel(verticalLayoutWidget_2);
        label_6->setObjectName(QStringLiteral("label_6"));

        horizontalLayout_4->addWidget(label_6);

        publicNum = new QLabel(verticalLayoutWidget_2);
        publicNum->setObjectName(QStringLiteral("publicNum"));

        horizontalLayout_4->addWidget(publicNum);


        verticalLayout_2->addLayout(horizontalLayout_4);

        horizontalLayout_5 = new QHBoxLayout();
        horizontalLayout_5->setObjectName(QStringLiteral("horizontalLayout_5"));
        label_8 = new QLabel(verticalLayoutWidget_2);
        label_8->setObjectName(QStringLiteral("label_8"));

        horizontalLayout_5->addWidget(label_8);

        updateNum = new QLabel(verticalLayoutWidget_2);
        updateNum->setObjectName(QStringLiteral("updateNum"));

        horizontalLayout_5->addWidget(updateNum);


        verticalLayout_2->addLayout(horizontalLayout_5);

        widget = new mapWidget(emerlisttab);
        widget->setObjectName(QStringLiteral("widget"));
        widget->setGeometry(QRect(20, 60, 501, 371));

        retranslateUi(emerlisttab);

        QMetaObject::connectSlotsByName(emerlisttab);
    } // setupUi

    void retranslateUi(QWidget *emerlisttab)
    {
        emerlisttab->setWindowTitle(QApplication::translate("emerlisttab", "Form", nullptr));
        emerID->setText(QApplication::translate("emerlisttab", "Emer ID", nullptr));
        emerTime->setText(QApplication::translate("emerlisttab", "Emer Time", nullptr));
        emerCoord->setText(QApplication::translate("emerlisttab", "Emer Coordinate", nullptr));
        label_4->setText(QApplication::translate("emerlisttab", "Sent to responders:", nullptr));
        responderNum->setText(QApplication::translate("emerlisttab", "100", nullptr));
        label_6->setText(QApplication::translate("emerlisttab", "Sent to public users:", nullptr));
        publicNum->setText(QApplication::translate("emerlisttab", "1000", nullptr));
        label_8->setText(QApplication::translate("emerlisttab", "Update reports received:", nullptr));
        updateNum->setText(QApplication::translate("emerlisttab", "20", nullptr));
    } // retranslateUi

};

namespace Ui {
    class emerlisttab: public Ui_emerlisttab {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_EMERLISTTAB_H
