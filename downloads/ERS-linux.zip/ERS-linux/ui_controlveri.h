/********************************************************************************
** Form generated from reading UI file 'controlveri.ui'
**
** Created by: Qt User Interface Compiler version 5.10.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CONTROLVERI_H
#define UI_CONTROLVERI_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_controlVeri
{
public:
    QLineEdit *DB_address;
    QLineEdit *DB_password;
    QPushButton *Cancel;
    QPushButton *Submit;

    void setupUi(QWidget *controlVeri)
    {
        if (controlVeri->objectName().isEmpty())
            controlVeri->setObjectName(QStringLiteral("controlVeri"));
        controlVeri->resize(900, 600);
        DB_address = new QLineEdit(controlVeri);
        DB_address->setObjectName(QStringLiteral("DB_address"));
        DB_address->setGeometry(QRect(280, 220, 321, 25));
        DB_password = new QLineEdit(controlVeri);
        DB_password->setObjectName(QStringLiteral("DB_password"));
        DB_password->setGeometry(QRect(280, 310, 321, 25));
        Cancel = new QPushButton(controlVeri);
        Cancel->setObjectName(QStringLiteral("Cancel"));
        Cancel->setGeometry(QRect(80, 500, 83, 25));
        Cancel->setStyleSheet(QStringLiteral("background-color: rgb(252, 233, 79);"));
        Submit = new QPushButton(controlVeri);
        Submit->setObjectName(QStringLiteral("Submit"));
        Submit->setGeometry(QRect(730, 510, 83, 25));
        Submit->setStyleSheet(QStringLiteral("background-color: rgb(252, 233, 79);"));

        retranslateUi(controlVeri);

        QMetaObject::connectSlotsByName(controlVeri);
    } // setupUi

    void retranslateUi(QWidget *controlVeri)
    {
        controlVeri->setWindowTitle(QApplication::translate("controlVeri", "Form", nullptr));
        DB_address->setPlaceholderText(QApplication::translate("controlVeri", "Database Address", nullptr));
        DB_password->setPlaceholderText(QApplication::translate("controlVeri", "Database Password", nullptr));
        Cancel->setText(QApplication::translate("controlVeri", "Cancel", nullptr));
        Submit->setText(QApplication::translate("controlVeri", "Submit", nullptr));
    } // retranslateUi

};

namespace Ui {
    class controlVeri: public Ui_controlVeri {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CONTROLVERI_H
