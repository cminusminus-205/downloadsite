/********************************************************************************
** Form generated from reading UI file 'publicinfoupdate.ui'
**
** Created by: Qt User Interface Compiler version 5.10.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_PUBLICINFOUPDATE_H
#define UI_PUBLICINFOUPDATE_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_publicInfoUpdate
{
public:
    QWidget *verticalLayoutWidget;
    QVBoxLayout *verticalLayout_2;
    QSpacerItem *verticalSpacer_3;
    QHBoxLayout *horizontalLayout_2;
    QLineEdit *Home;
    QLineEdit *HomeZip;
    QHBoxLayout *horizontalLayout;
    QLineEdit *Work;
    QLineEdit *WorkZip;
    QSpacerItem *verticalSpacer;
    QLabel *label;
    QGridLayout *gridLayout;
    QCheckBox *bicycle;
    QCheckBox *plane;
    QCheckBox *walk;
    QCheckBox *subway;
    QCheckBox *railway;
    QCheckBox *ferry;
    QCheckBox *bus;
    QCheckBox *vehicle;
    QLabel *lable;
    QSpacerItem *verticalSpacer_2;
    QLabel *label_2;
    QHBoxLayout *horizontalLayout_3;
    QPushButton *cancel;
    QSpacerItem *horizontalSpacer;
    QPushButton *next;

    void setupUi(QWidget *publicInfoUpdate)
    {
        if (publicInfoUpdate->objectName().isEmpty())
            publicInfoUpdate->setObjectName(QStringLiteral("publicInfoUpdate"));
        publicInfoUpdate->resize(900, 600);
        QPalette palette;
        QBrush brush(QColor(0, 0, 0, 255));
        brush.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::WindowText, brush);
        QBrush brush1(QColor(239, 41, 41, 255));
        brush1.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::Button, brush1);
        QBrush brush2(QColor(255, 147, 147, 255));
        brush2.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::Light, brush2);
        QBrush brush3(QColor(247, 94, 94, 255));
        brush3.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::Midlight, brush3);
        QBrush brush4(QColor(119, 20, 20, 255));
        brush4.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::Dark, brush4);
        QBrush brush5(QColor(159, 27, 27, 255));
        brush5.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::Mid, brush5);
        palette.setBrush(QPalette::Active, QPalette::Text, brush);
        QBrush brush6(QColor(255, 255, 255, 255));
        brush6.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::BrightText, brush6);
        palette.setBrush(QPalette::Active, QPalette::ButtonText, brush);
        palette.setBrush(QPalette::Active, QPalette::Base, brush6);
        QBrush brush7(QColor(238, 238, 236, 255));
        brush7.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::Window, brush7);
        palette.setBrush(QPalette::Active, QPalette::Shadow, brush);
        QBrush brush8(QColor(247, 148, 148, 255));
        brush8.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::AlternateBase, brush8);
        QBrush brush9(QColor(255, 255, 220, 255));
        brush9.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::ToolTipBase, brush9);
        palette.setBrush(QPalette::Active, QPalette::ToolTipText, brush);
        palette.setBrush(QPalette::Inactive, QPalette::WindowText, brush);
        palette.setBrush(QPalette::Inactive, QPalette::Button, brush1);
        palette.setBrush(QPalette::Inactive, QPalette::Light, brush2);
        palette.setBrush(QPalette::Inactive, QPalette::Midlight, brush3);
        palette.setBrush(QPalette::Inactive, QPalette::Dark, brush4);
        palette.setBrush(QPalette::Inactive, QPalette::Mid, brush5);
        palette.setBrush(QPalette::Inactive, QPalette::Text, brush);
        palette.setBrush(QPalette::Inactive, QPalette::BrightText, brush6);
        palette.setBrush(QPalette::Inactive, QPalette::ButtonText, brush);
        palette.setBrush(QPalette::Inactive, QPalette::Base, brush6);
        palette.setBrush(QPalette::Inactive, QPalette::Window, brush7);
        palette.setBrush(QPalette::Inactive, QPalette::Shadow, brush);
        palette.setBrush(QPalette::Inactive, QPalette::AlternateBase, brush8);
        palette.setBrush(QPalette::Inactive, QPalette::ToolTipBase, brush9);
        palette.setBrush(QPalette::Inactive, QPalette::ToolTipText, brush);
        palette.setBrush(QPalette::Disabled, QPalette::WindowText, brush4);
        palette.setBrush(QPalette::Disabled, QPalette::Button, brush1);
        palette.setBrush(QPalette::Disabled, QPalette::Light, brush2);
        palette.setBrush(QPalette::Disabled, QPalette::Midlight, brush3);
        palette.setBrush(QPalette::Disabled, QPalette::Dark, brush4);
        palette.setBrush(QPalette::Disabled, QPalette::Mid, brush5);
        palette.setBrush(QPalette::Disabled, QPalette::Text, brush4);
        palette.setBrush(QPalette::Disabled, QPalette::BrightText, brush6);
        palette.setBrush(QPalette::Disabled, QPalette::ButtonText, brush4);
        palette.setBrush(QPalette::Disabled, QPalette::Base, brush7);
        palette.setBrush(QPalette::Disabled, QPalette::Window, brush7);
        palette.setBrush(QPalette::Disabled, QPalette::Shadow, brush);
        palette.setBrush(QPalette::Disabled, QPalette::AlternateBase, brush1);
        palette.setBrush(QPalette::Disabled, QPalette::ToolTipBase, brush9);
        palette.setBrush(QPalette::Disabled, QPalette::ToolTipText, brush);
        publicInfoUpdate->setPalette(palette);
        QFont font;
        font.setFamily(QStringLiteral("DejaVu Sans"));
        font.setBold(false);
        font.setWeight(50);
        publicInfoUpdate->setFont(font);
        verticalLayoutWidget = new QWidget(publicInfoUpdate);
        verticalLayoutWidget->setObjectName(QStringLiteral("verticalLayoutWidget"));
        verticalLayoutWidget->setGeometry(QRect(170, 10, 551, 581));
        verticalLayout_2 = new QVBoxLayout(verticalLayoutWidget);
        verticalLayout_2->setObjectName(QStringLiteral("verticalLayout_2"));
        verticalLayout_2->setSizeConstraint(QLayout::SetFixedSize);
        verticalLayout_2->setContentsMargins(0, 0, 0, 0);
        verticalSpacer_3 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Preferred);

        verticalLayout_2->addItem(verticalSpacer_3);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName(QStringLiteral("horizontalLayout_2"));
        horizontalLayout_2->setSizeConstraint(QLayout::SetFixedSize);
        Home = new QLineEdit(verticalLayoutWidget);
        Home->setObjectName(QStringLiteral("Home"));

        horizontalLayout_2->addWidget(Home);

        HomeZip = new QLineEdit(verticalLayoutWidget);
        HomeZip->setObjectName(QStringLiteral("HomeZip"));

        horizontalLayout_2->addWidget(HomeZip);


        verticalLayout_2->addLayout(horizontalLayout_2);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        horizontalLayout->setSizeConstraint(QLayout::SetFixedSize);
        Work = new QLineEdit(verticalLayoutWidget);
        Work->setObjectName(QStringLiteral("Work"));

        horizontalLayout->addWidget(Work);

        WorkZip = new QLineEdit(verticalLayoutWidget);
        WorkZip->setObjectName(QStringLiteral("WorkZip"));

        horizontalLayout->addWidget(WorkZip);


        verticalLayout_2->addLayout(horizontalLayout);

        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Preferred);

        verticalLayout_2->addItem(verticalSpacer);

        label = new QLabel(verticalLayoutWidget);
        label->setObjectName(QStringLiteral("label"));
        QFont font1;
        font1.setPointSize(12);
        label->setFont(font1);

        verticalLayout_2->addWidget(label, 0, Qt::AlignBottom);

        gridLayout = new QGridLayout();
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        bicycle = new QCheckBox(verticalLayoutWidget);
        bicycle->setObjectName(QStringLiteral("bicycle"));
        bicycle->setChecked(true);

        gridLayout->addWidget(bicycle, 2, 1, 1, 1);

        plane = new QCheckBox(verticalLayoutWidget);
        plane->setObjectName(QStringLiteral("plane"));
        plane->setChecked(true);

        gridLayout->addWidget(plane, 3, 1, 1, 1);

        walk = new QCheckBox(verticalLayoutWidget);
        walk->setObjectName(QStringLiteral("walk"));
        walk->setChecked(true);

        gridLayout->addWidget(walk, 0, 0, 1, 1);

        subway = new QCheckBox(verticalLayoutWidget);
        subway->setObjectName(QStringLiteral("subway"));
        subway->setChecked(true);

        gridLayout->addWidget(subway, 3, 0, 1, 1);

        railway = new QCheckBox(verticalLayoutWidget);
        railway->setObjectName(QStringLiteral("railway"));
        railway->setChecked(true);

        gridLayout->addWidget(railway, 2, 0, 1, 1);

        ferry = new QCheckBox(verticalLayoutWidget);
        ferry->setObjectName(QStringLiteral("ferry"));
        ferry->setChecked(true);

        gridLayout->addWidget(ferry, 1, 1, 1, 1);

        bus = new QCheckBox(verticalLayoutWidget);
        bus->setObjectName(QStringLiteral("bus"));
        bus->setChecked(true);

        gridLayout->addWidget(bus, 1, 0, 1, 1);

        vehicle = new QCheckBox(verticalLayoutWidget);
        vehicle->setObjectName(QStringLiteral("vehicle"));
        vehicle->setChecked(true);

        gridLayout->addWidget(vehicle, 0, 1, 1, 1);


        verticalLayout_2->addLayout(gridLayout);

        lable = new QLabel(verticalLayoutWidget);
        lable->setObjectName(QStringLiteral("lable"));
        QPalette palette1;
        palette1.setBrush(QPalette::Active, QPalette::WindowText, brush);
        palette1.setBrush(QPalette::Active, QPalette::Button, brush1);
        palette1.setBrush(QPalette::Active, QPalette::Light, brush2);
        palette1.setBrush(QPalette::Active, QPalette::Midlight, brush3);
        palette1.setBrush(QPalette::Active, QPalette::Dark, brush4);
        palette1.setBrush(QPalette::Active, QPalette::Mid, brush5);
        palette1.setBrush(QPalette::Active, QPalette::Text, brush);
        palette1.setBrush(QPalette::Active, QPalette::BrightText, brush6);
        palette1.setBrush(QPalette::Active, QPalette::ButtonText, brush);
        palette1.setBrush(QPalette::Active, QPalette::Base, brush6);
        palette1.setBrush(QPalette::Active, QPalette::Window, brush7);
        palette1.setBrush(QPalette::Active, QPalette::Shadow, brush);
        palette1.setBrush(QPalette::Active, QPalette::AlternateBase, brush8);
        palette1.setBrush(QPalette::Active, QPalette::ToolTipBase, brush9);
        palette1.setBrush(QPalette::Active, QPalette::ToolTipText, brush);
        palette1.setBrush(QPalette::Inactive, QPalette::WindowText, brush);
        palette1.setBrush(QPalette::Inactive, QPalette::Button, brush1);
        palette1.setBrush(QPalette::Inactive, QPalette::Light, brush2);
        palette1.setBrush(QPalette::Inactive, QPalette::Midlight, brush3);
        palette1.setBrush(QPalette::Inactive, QPalette::Dark, brush4);
        palette1.setBrush(QPalette::Inactive, QPalette::Mid, brush5);
        palette1.setBrush(QPalette::Inactive, QPalette::Text, brush);
        palette1.setBrush(QPalette::Inactive, QPalette::BrightText, brush6);
        palette1.setBrush(QPalette::Inactive, QPalette::ButtonText, brush);
        palette1.setBrush(QPalette::Inactive, QPalette::Base, brush6);
        palette1.setBrush(QPalette::Inactive, QPalette::Window, brush7);
        palette1.setBrush(QPalette::Inactive, QPalette::Shadow, brush);
        palette1.setBrush(QPalette::Inactive, QPalette::AlternateBase, brush8);
        palette1.setBrush(QPalette::Inactive, QPalette::ToolTipBase, brush9);
        palette1.setBrush(QPalette::Inactive, QPalette::ToolTipText, brush);
        palette1.setBrush(QPalette::Disabled, QPalette::WindowText, brush4);
        palette1.setBrush(QPalette::Disabled, QPalette::Button, brush1);
        palette1.setBrush(QPalette::Disabled, QPalette::Light, brush2);
        palette1.setBrush(QPalette::Disabled, QPalette::Midlight, brush3);
        palette1.setBrush(QPalette::Disabled, QPalette::Dark, brush4);
        palette1.setBrush(QPalette::Disabled, QPalette::Mid, brush5);
        palette1.setBrush(QPalette::Disabled, QPalette::Text, brush4);
        palette1.setBrush(QPalette::Disabled, QPalette::BrightText, brush6);
        palette1.setBrush(QPalette::Disabled, QPalette::ButtonText, brush4);
        palette1.setBrush(QPalette::Disabled, QPalette::Base, brush7);
        palette1.setBrush(QPalette::Disabled, QPalette::Window, brush7);
        palette1.setBrush(QPalette::Disabled, QPalette::Shadow, brush);
        palette1.setBrush(QPalette::Disabled, QPalette::AlternateBase, brush1);
        palette1.setBrush(QPalette::Disabled, QPalette::ToolTipBase, brush9);
        palette1.setBrush(QPalette::Disabled, QPalette::ToolTipText, brush);
        lable->setPalette(palette1);
        QFont font2;
        font2.setFamily(QStringLiteral("DejaVu Sans Mono"));
        font2.setPointSize(9);
        font2.setItalic(true);
        lable->setFont(font2);

        verticalLayout_2->addWidget(lable, 0, Qt::AlignTop);

        verticalSpacer_2 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Preferred);

        verticalLayout_2->addItem(verticalSpacer_2);

        label_2 = new QLabel(verticalLayoutWidget);
        label_2->setObjectName(QStringLiteral("label_2"));
        QSizePolicy sizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(label_2->sizePolicy().hasHeightForWidth());
        label_2->setSizePolicy(sizePolicy);
        QFont font3;
        font3.setFamily(QStringLiteral("DejaVu Sans Mono"));
        font3.setItalic(true);
        label_2->setFont(font3);

        verticalLayout_2->addWidget(label_2);

        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setObjectName(QStringLiteral("horizontalLayout_3"));
        horizontalLayout_3->setSizeConstraint(QLayout::SetFixedSize);
        cancel = new QPushButton(verticalLayoutWidget);
        cancel->setObjectName(QStringLiteral("cancel"));

        horizontalLayout_3->addWidget(cancel);

        horizontalSpacer = new QSpacerItem(80, 20, QSizePolicy::Fixed, QSizePolicy::Minimum);

        horizontalLayout_3->addItem(horizontalSpacer);

        next = new QPushButton(verticalLayoutWidget);
        next->setObjectName(QStringLiteral("next"));

        horizontalLayout_3->addWidget(next);


        verticalLayout_2->addLayout(horizontalLayout_3);


        retranslateUi(publicInfoUpdate);

        QMetaObject::connectSlotsByName(publicInfoUpdate);
    } // setupUi

    void retranslateUi(QWidget *publicInfoUpdate)
    {
        publicInfoUpdate->setWindowTitle(QApplication::translate("publicInfoUpdate", "Form", nullptr));
        Home->setPlaceholderText(QApplication::translate("publicInfoUpdate", "Home Address", nullptr));
        HomeZip->setText(QString());
        HomeZip->setPlaceholderText(QApplication::translate("publicInfoUpdate", "Zip Code", nullptr));
        Work->setText(QString());
        Work->setPlaceholderText(QApplication::translate("publicInfoUpdate", "Work Address", nullptr));
        WorkZip->setText(QString());
        WorkZip->setPlaceholderText(QApplication::translate("publicInfoUpdate", "Zip Code", nullptr));
        label->setText(QApplication::translate("publicInfoUpdate", "Choose your ways of transportation:", nullptr));
        bicycle->setText(QApplication::translate("publicInfoUpdate", "Bicycle", nullptr));
        plane->setText(QApplication::translate("publicInfoUpdate", "Plane", nullptr));
        walk->setText(QApplication::translate("publicInfoUpdate", "Walk", nullptr));
        subway->setText(QApplication::translate("publicInfoUpdate", "Subway", nullptr));
        railway->setText(QApplication::translate("publicInfoUpdate", "Railway", nullptr));
        ferry->setText(QApplication::translate("publicInfoUpdate", "Ferry", nullptr));
        bus->setText(QApplication::translate("publicInfoUpdate", "Bus", nullptr));
        vehicle->setText(QApplication::translate("publicInfoUpdate", "Private vehicle", nullptr));
        lable->setText(QApplication::translate("publicInfoUpdate", "It is recommended to check all boxes.", nullptr));
        label_2->setText(QApplication::translate("publicInfoUpdate", "If left blank. the according information will remain unchanged.", nullptr));
        cancel->setText(QApplication::translate("publicInfoUpdate", "Cancel", nullptr));
        next->setText(QApplication::translate("publicInfoUpdate", "Confirm", nullptr));
    } // retranslateUi

};

namespace Ui {
    class publicInfoUpdate: public Ui_publicInfoUpdate {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_PUBLICINFOUPDATE_H
