/********************************************************************************
** Form generated from reading UI file 'drilldesign.ui'
**
** Created by: Qt User Interface Compiler version 5.10.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_DRILLDESIGN_H
#define UI_DRILLDESIGN_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDateTimeEdit>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPlainTextEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QRadioButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_DrillDesign
{
public:
    QWidget *layoutWidget;
    QHBoxLayout *horizontalLayout;
    QVBoxLayout *verticalLayout;
    QLabel *Type;
    QComboBox *Em_Type;
    QLabel *Location;
    QLineEdit *Location_Input;
    QLabel *Location_2;
    QLineEdit *Location_Input_2;
    QLabel *label;
    QHBoxLayout *horizontalLayout_2;
    QLineEdit *x_;
    QLineEdit *y_;
    QLabel *Time;
    QDateTimeEdit *Date_Time;
    QLabel *Description;
    QPlainTextEdit *Decription_Input;
    QRadioButton *sendToPublic;
    QHBoxLayout *horizontalLayout_5;
    QPushButton *cancel;
    QSpacerItem *horizontalSpacer_3;
    QPushButton *Submit;
    QLabel *label_2;

    void setupUi(QWidget *DrillDesign)
    {
        if (DrillDesign->objectName().isEmpty())
            DrillDesign->setObjectName(QStringLiteral("DrillDesign"));
        DrillDesign->resize(900, 600);
        QSizePolicy sizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(DrillDesign->sizePolicy().hasHeightForWidth());
        DrillDesign->setSizePolicy(sizePolicy);
        layoutWidget = new QWidget(DrillDesign);
        layoutWidget->setObjectName(QStringLiteral("layoutWidget"));
        layoutWidget->setGeometry(QRect(110, 50, 614, 496));
        horizontalLayout = new QHBoxLayout(layoutWidget);
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        horizontalLayout->setContentsMargins(0, 0, 0, 0);
        verticalLayout = new QVBoxLayout();
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        Type = new QLabel(layoutWidget);
        Type->setObjectName(QStringLiteral("Type"));

        verticalLayout->addWidget(Type);

        Em_Type = new QComboBox(layoutWidget);
        Em_Type->addItem(QString());
        Em_Type->addItem(QString());
        Em_Type->addItem(QString());
        Em_Type->addItem(QString());
        Em_Type->addItem(QString());
        Em_Type->addItem(QString());
        Em_Type->addItem(QString());
        Em_Type->setObjectName(QStringLiteral("Em_Type"));
        Em_Type->setStyleSheet(QStringLiteral("background-color: rgb(252, 233, 79);"));

        verticalLayout->addWidget(Em_Type);

        Location = new QLabel(layoutWidget);
        Location->setObjectName(QStringLiteral("Location"));

        verticalLayout->addWidget(Location);

        Location_Input = new QLineEdit(layoutWidget);
        Location_Input->setObjectName(QStringLiteral("Location_Input"));

        verticalLayout->addWidget(Location_Input);

        Location_2 = new QLabel(layoutWidget);
        Location_2->setObjectName(QStringLiteral("Location_2"));

        verticalLayout->addWidget(Location_2);

        Location_Input_2 = new QLineEdit(layoutWidget);
        Location_Input_2->setObjectName(QStringLiteral("Location_Input_2"));

        verticalLayout->addWidget(Location_Input_2);

        label = new QLabel(layoutWidget);
        label->setObjectName(QStringLiteral("label"));

        verticalLayout->addWidget(label);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName(QStringLiteral("horizontalLayout_2"));
        x_ = new QLineEdit(layoutWidget);
        x_->setObjectName(QStringLiteral("x_"));

        horizontalLayout_2->addWidget(x_);

        y_ = new QLineEdit(layoutWidget);
        y_->setObjectName(QStringLiteral("y_"));

        horizontalLayout_2->addWidget(y_);


        verticalLayout->addLayout(horizontalLayout_2);

        Time = new QLabel(layoutWidget);
        Time->setObjectName(QStringLiteral("Time"));

        verticalLayout->addWidget(Time);

        Date_Time = new QDateTimeEdit(layoutWidget);
        Date_Time->setObjectName(QStringLiteral("Date_Time"));

        verticalLayout->addWidget(Date_Time);

        Description = new QLabel(layoutWidget);
        Description->setObjectName(QStringLiteral("Description"));

        verticalLayout->addWidget(Description);

        Decription_Input = new QPlainTextEdit(layoutWidget);
        Decription_Input->setObjectName(QStringLiteral("Decription_Input"));

        verticalLayout->addWidget(Decription_Input);

        sendToPublic = new QRadioButton(layoutWidget);
        sendToPublic->setObjectName(QStringLiteral("sendToPublic"));
        sendToPublic->setChecked(true);

        verticalLayout->addWidget(sendToPublic);

        horizontalLayout_5 = new QHBoxLayout();
        horizontalLayout_5->setObjectName(QStringLiteral("horizontalLayout_5"));
        cancel = new QPushButton(layoutWidget);
        cancel->setObjectName(QStringLiteral("cancel"));
        cancel->setStyleSheet(QStringLiteral("background-color: rgb(252, 233, 79);"));

        horizontalLayout_5->addWidget(cancel);

        horizontalSpacer_3 = new QSpacerItem(100, 20, QSizePolicy::Fixed, QSizePolicy::Minimum);

        horizontalLayout_5->addItem(horizontalSpacer_3);

        Submit = new QPushButton(layoutWidget);
        Submit->setObjectName(QStringLiteral("Submit"));
        Submit->setStyleSheet(QStringLiteral("background-color: rgb(252, 233, 79);"));

        horizontalLayout_5->addWidget(Submit);


        verticalLayout->addLayout(horizontalLayout_5);

        label_2 = new QLabel(layoutWidget);
        label_2->setObjectName(QStringLiteral("label_2"));
        QFont font;
        font.setFamily(QStringLiteral("DejaVu Sans Mono"));
        font.setItalic(true);
        label_2->setFont(font);

        verticalLayout->addWidget(label_2);


        horizontalLayout->addLayout(verticalLayout);


        retranslateUi(DrillDesign);

        QMetaObject::connectSlotsByName(DrillDesign);
    } // setupUi

    void retranslateUi(QWidget *DrillDesign)
    {
        DrillDesign->setWindowTitle(QApplication::translate("DrillDesign", "Form", nullptr));
        Type->setText(QApplication::translate("DrillDesign", "Type", nullptr));
        Em_Type->setItemText(0, QApplication::translate("DrillDesign", "Fire", nullptr));
        Em_Type->setItemText(1, QApplication::translate("DrillDesign", "Gunshot", nullptr));
        Em_Type->setItemText(2, QApplication::translate("DrillDesign", "Earthquake", nullptr));
        Em_Type->setItemText(3, QApplication::translate("DrillDesign", "Flood", nullptr));
        Em_Type->setItemText(4, QApplication::translate("DrillDesign", "Storm", nullptr));
        Em_Type->setItemText(5, QApplication::translate("DrillDesign", "Zombie", nullptr));
        Em_Type->setItemText(6, QApplication::translate("DrillDesign", "Other(please specify in description)", nullptr));

        Location->setText(QApplication::translate("DrillDesign", "Location", nullptr));
        Location_2->setText(QApplication::translate("DrillDesign", "Zipcode", nullptr));
        label->setText(QApplication::translate("DrillDesign", "Coordinates", nullptr));
        x_->setPlaceholderText(QApplication::translate("DrillDesign", "X-coordinate", nullptr));
        y_->setPlaceholderText(QApplication::translate("DrillDesign", "Y-coordinate", nullptr));
        Time->setText(QApplication::translate("DrillDesign", "Time", nullptr));
        Description->setText(QApplication::translate("DrillDesign", "Description", nullptr));
        sendToPublic->setText(QApplication::translate("DrillDesign", "Send public users emergency simulation alerts", nullptr));
        cancel->setText(QApplication::translate("DrillDesign", "Cancel", nullptr));
        Submit->setText(QApplication::translate("DrillDesign", "Create Simulation", nullptr));
        label_2->setText(QApplication::translate("DrillDesign", "Alerts will be sent to responders / and public after the simulation is created", nullptr));
    } // retranslateUi

};

namespace Ui {
    class DrillDesign: public Ui_DrillDesign {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_DRILLDESIGN_H
