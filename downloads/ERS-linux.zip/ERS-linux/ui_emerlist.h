/********************************************************************************
** Form generated from reading UI file 'emerlist.ui'
**
** Created by: Qt User Interface Compiler version 5.10.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_EMERLIST_H
#define UI_EMERLIST_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTabWidget>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_emerList
{
public:
    QWidget *verticalLayoutWidget;
    QVBoxLayout *verticalLayout;
    QTabWidget *tabWidget;
    QWidget *tab;
    QWidget *tab_2;
    QHBoxLayout *horizontalLayout;
    QPushButton *back;
    QPushButton *view;
    QPushButton *endEmergency;

    void setupUi(QWidget *emerList)
    {
        if (emerList->objectName().isEmpty())
            emerList->setObjectName(QStringLiteral("emerList"));
        emerList->resize(900, 600);
        QSizePolicy sizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(emerList->sizePolicy().hasHeightForWidth());
        emerList->setSizePolicy(sizePolicy);
        verticalLayoutWidget = new QWidget(emerList);
        verticalLayoutWidget->setObjectName(QStringLiteral("verticalLayoutWidget"));
        verticalLayoutWidget->setGeometry(QRect(10, 10, 881, 583));
        verticalLayout = new QVBoxLayout(verticalLayoutWidget);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        tabWidget = new QTabWidget(verticalLayoutWidget);
        tabWidget->setObjectName(QStringLiteral("tabWidget"));
        tab = new QWidget();
        tab->setObjectName(QStringLiteral("tab"));
        tabWidget->addTab(tab, QString());
        tab_2 = new QWidget();
        tab_2->setObjectName(QStringLiteral("tab_2"));
        tabWidget->addTab(tab_2, QString());

        verticalLayout->addWidget(tabWidget);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        back = new QPushButton(verticalLayoutWidget);
        back->setObjectName(QStringLiteral("back"));
        back->setStyleSheet(QStringLiteral("background-color: rgb(252, 233, 79);"));

        horizontalLayout->addWidget(back);

        view = new QPushButton(verticalLayoutWidget);
        view->setObjectName(QStringLiteral("view"));
        view->setStyleSheet(QStringLiteral("background-color: rgb(252, 233, 79);"));

        horizontalLayout->addWidget(view);

        endEmergency = new QPushButton(verticalLayoutWidget);
        endEmergency->setObjectName(QStringLiteral("endEmergency"));
        endEmergency->setStyleSheet(QStringLiteral("background-color: rgb(252, 233, 79);"));

        horizontalLayout->addWidget(endEmergency);


        verticalLayout->addLayout(horizontalLayout);


        retranslateUi(emerList);

        tabWidget->setCurrentIndex(0);


        QMetaObject::connectSlotsByName(emerList);
    } // setupUi

    void retranslateUi(QWidget *emerList)
    {
        emerList->setWindowTitle(QApplication::translate("emerList", "Form", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(tab), QApplication::translate("emerList", "Tab 1", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(tab_2), QApplication::translate("emerList", "Tab 2", nullptr));
        back->setText(QApplication::translate("emerList", "Back", nullptr));
        view->setText(QApplication::translate("emerList", "View Report", nullptr));
        endEmergency->setText(QApplication::translate("emerList", "End this emergency", nullptr));
    } // retranslateUi

};

namespace Ui {
    class emerList: public Ui_emerList {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_EMERLIST_H
